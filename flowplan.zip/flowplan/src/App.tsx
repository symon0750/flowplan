import React, { useState, useEffect } from 'react';
import { Calendar, CheckSquare, Plus, Folder, Settings } from 'lucide-react';
import { clsx } from 'clsx';
import { twMerge } from 'tailwind-merge';

// Tabs
import AgendaTab from './tabs/AgendaTab';
import TasksTab from './tabs/TasksTab';
import ProjectsTab from './tabs/ProjectsTab';
import SettingsTab from './tabs/SettingsTab';
import TaskModal from './components/TaskModal';
import { useStore } from './store/useStore';

type Tab = 'agenda' | 'tasks' | 'projects' | 'settings';

export default function App() {
  const [activeTab, setActiveTab] = useState<Tab>('agenda');
  const [isTaskModalOpen, setIsTaskModalOpen] = useState(false);
  const [isLoading, setIsLoading] = useState(true);
  
  const loadFromDB = useStore((state) => state.loadFromDB);

  useEffect(() => {
    // Carrega dados do IndexedDB ao iniciar
    loadFromDB().then(() => setIsLoading(false));
  }, [loadFromDB]);

  if (isLoading) {
    return (
      <div className="flex items-center justify-center h-screen bg-gray-50">
        <div className="text-center">
          <div className="text-3xl font-bold text-gray-800 mb-2">FlowPlan</div>
          <div className="text-gray-500">Carregando...</div>
        </div>
      </div>
    );
  }

  return (
    <div className="flex flex-col h-screen bg-gray-50 overflow-hidden font-sans text-slate-800">
      <main className="flex-1 overflow-y-auto pb-16 relative">
        {activeTab === 'agenda' && <AgendaTab />}
        {activeTab === 'tasks' && <TasksTab />}
        {activeTab === 'projects' && <ProjectsTab />}
        {activeTab === 'settings' && <SettingsTab />}
      </main>

      <nav className="fixed bottom-0 left-0 right-0 bg-white border-t border-gray-200 px-6 h-16 flex items-center justify-between z-50">
        <button 
          onClick={() => setActiveTab('agenda')}
          className={clsx('flex flex-col items-center justify-center w-12', activeTab === 'agenda' ? 'text-blue-600' : 'text-gray-400')}
        >
          <Calendar size={24} />
          <span className="text-[10px] mt-1 font-medium">Agenda</span>
        </button>
        
        <button 
          onClick={() => setActiveTab('tasks')}
          className={clsx('flex flex-col items-center justify-center w-12', activeTab === 'tasks' ? 'text-blue-600' : 'text-gray-400')}
        >
          <CheckSquare size={24} />
          <span className="text-[10px] mt-1 font-medium">Tarefas</span>
        </button>

        <div className="relative w-16 h-full flex justify-center">
          <button 
            onClick={() => setIsTaskModalOpen(true)}
            className="absolute -top-6 bg-blue-600 text-white rounded-full p-4 shadow-lg hover:bg-blue-700 hover:scale-105 transition-all flex items-center justify-center z-50"
          >
            <Plus size={32} />
          </button>
        </div>

        <button 
          onClick={() => setActiveTab('projects')}
          className={clsx('flex flex-col items-center justify-center w-12', activeTab === 'projects' ? 'text-blue-600' : 'text-gray-400')}
        >
          <Folder size={24} />
          <span className="text-[10px] mt-1 font-medium">Projetos</span>
        </button>

        <button 
          onClick={() => setActiveTab('settings')}
          className={clsx('flex flex-col items-center justify-center w-12', activeTab === 'settings' ? 'text-blue-600' : 'text-gray-400')}
        >
          <Settings size={24} />
          <span className="text-[10px] mt-1 font-medium">Ajustes</span>
        </button>
      </nav>

      {isTaskModalOpen && (
        <TaskModal onClose={() => setIsTaskModalOpen(false)} />
      )}
    </div>
  );
}
