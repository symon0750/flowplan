import { Task, TimeProfile, Slot } from './types';
import { v4 as uuidv4 } from 'uuid';
import {
  addDays,
  addWeeks,
  startOfDay,
  parseISO,
  isBefore,
  isAfter,
  isSameDay,
  setHours,
  setMinutes,
  getDay,
  format,
  addMinutes as addMinutesDateFns,
} from 'date-fns';

export interface SchedulingResult {
  slots: Slot[];
  unscheduledTaskIds: string[];
  errors: string[];
}

/**
 * Determina se uma tarefa é elegível para agendamento automático
 */
export function isTaskEligibleForScheduling(task: Task, now: Date = new Date()): boolean {
  // Não agendra tarefas concluídas
  if (task.status === 'completed') return false;

  // Não agenda tarefas com evento fixo (já têm horário específico)
  if (task.isFixed) return false;

  // Não agenda tarefas atrasadas (prazo passou e ainda não foi concluída)
  if (task.status === 'delayed') return false;

  // Não agenda tarefas sem disponibilidade ainda
  if (task.availableFrom && isBefore(now, parseISO(task.availableFrom))) {
    return false;
  }

  // Agenda se não tem prazo ou prazo ainda é futuro
  if (task.deadline) {
    const deadline = parseISO(task.deadline);
    if (isBefore(deadline, startOfDay(now))) {
      // Prazo já passou - marcar como atrasada em vez de agendar
      return false;
    }
  }

  return true;
}

/**
 * Calcula se uma tarefa está atrasada (prazo passou, não concluída)
 */
export function calculateTaskStatus(task: Task, now: Date = new Date()): void {
  if (task.status === 'completed') return;

  if (task.deadline) {
    const deadline = parseISO(task.deadline);
    if (
      isBefore(deadline, now) &&
      task.status !== 'scheduled' &&
      !task.isFixed
    ) {
      task.status = 'delayed';
    }
  }
}

/**
 * Gera ocorrências de tarefas recorrentes a partir de uma data
 */
export function generateRecurrenceOccurrences(
  task: Task,
  fromDate: Date = new Date(),
  toDate: Date = addDays(new Date(), 60)
): Task[] {
  if (task.repeat === 'none') return [task];

  const occurrences: Task[] = [];
  let currentDate = startOfDay(fromDate);
  const endDate = startOfDay(toDate);
  const interval = task.repeatInterval || 1;

  while (isBefore(currentDate, endDate) || isSameDay(currentDate, endDate)) {
    let shouldAdd = false;

    if (task.repeat === 'daily') {
      const daysDiff = Math.floor(
        (currentDate.getTime() - startOfDay(fromDate).getTime()) /
          (24 * 60 * 60 * 1000)
      );
      shouldAdd = daysDiff % interval === 0;
    } else if (task.repeat === 'weekly') {
      const dayOfWeek = getDay(currentDate);
      const repeatDays = task.repeatDays || [0, 1, 2, 3, 4, 5, 6];

      if (repeatDays.includes(dayOfWeek)) {
        const weeksDiff = Math.floor(
          (currentDate.getTime() - startOfDay(fromDate).getTime()) /
            (7 * 24 * 60 * 60 * 1000)
        );
        shouldAdd = weeksDiff % interval === 0;
      }
    }

    if (shouldAdd) {
      occurrences.push({
        ...task,
        id: `${task.id}-${format(currentDate, 'yyyy-MM-dd')}`,
      });
    }

    currentDate = addDays(currentDate, 1);
  }

  return occurrences;
}

/**
 * Divide uma tarefa em múltiplos slots respeitando a sessão mínima
 */
export function dividableTaskToSlots(
  task: Task,
  startTime: Date
): Slot[] {
  if (!task.divisible) {
    const endTime = addMinutesDateFns(startTime, task.duration);
    return [
      {
        id: uuidv4(),
        taskId: task.id,
        start: startTime.toISOString(),
        end: endTime.toISOString(),
        isFixed: false,
        createdAt: new Date().toISOString(),
      },
    ];
  }

  const slots: Slot[] = [];
  const minSession = task.minSession || 30;
  let remainingDuration = task.duration;
  let currentStart = new Date(startTime);

  while (remainingDuration > 0) {
    if (remainingDuration < 10) {
      if (slots.length > 0) {
        const lastSlot = slots[slots.length - 1];
        lastSlot.end = addMinutesDateFns(currentStart, remainingDuration).toISOString();
      }
      break;
    }

    let blockDuration = minSession;
    if (remainingDuration <= minSession) {
      blockDuration = remainingDuration;
    } else if (remainingDuration <= minSession * 2) {
      blockDuration = Math.ceil(remainingDuration / 2);
    }

    const endTime = addMinutesDateFns(currentStart, blockDuration);
    slots.push({
      id: uuidv4(),
      taskId: task.id,
      start: currentStart.toISOString(),
      end: endTime.toISOString(),
      isFixed: false,
      createdAt: new Date().toISOString(),
    });

    remainingDuration -= blockDuration;
    currentStart = endTime;
  }

  return slots;
}

/**
 * Encontra próximo slot disponível
 */
export function findNextAvailableSlot(
  profile: TimeProfile,
  existingSlots: Slot[],
  requiredDuration: number,
  fromDate: Date = new Date(),
  toDate: Date = addDays(new Date(), 60)
): { start: Date; end: Date } | null {
  let currentDate = startOfDay(fromDate);
  const endDate = startOfDay(toDate);

  while (isBefore(currentDate, endDate) || isSameDay(currentDate, endDate)) {
    const dayOfWeek = getDay(currentDate);
    const dayConfig = profile.days[dayOfWeek];

    if (!dayConfig || !dayConfig.active) {
      currentDate = addDays(currentDate, 1);
      continue;
    }

    const startTime = dayConfig.start || profile.standardStart;
    const endTime = dayConfig.end || profile.standardEnd;
    const pauses = dayConfig.pauses || profile.standardPauses;

    const [startHour, startMin] = startTime.split(':').map(Number);
    const [endHour, endMin] = endTime.split(':').map(Number);
    const dayStart = setMinutes(setHours(currentDate, startHour), startMin);
    const dayEnd = setMinutes(setHours(currentDate, endHour), endMin);

    const searchStart = isBefore(dayStart, fromDate) ? fromDate : dayStart;

    if (isBefore(searchStart, dayEnd)) {
      const busyTimes = existingSlots
        .filter((slot) => {
          const slotStart = parseISO(slot.start);
          const slotEnd = parseISO(slot.end);
          return (
            isSameDay(slotStart, currentDate) &&
            isBefore(slotStart, dayEnd) &&
            isAfter(slotEnd, searchStart)
          );
        })
        .map((slot) => ({
          start: parseISO(slot.start),
          end: parseISO(slot.end),
        }))
        .sort((a, b) => a.start.getTime() - b.start.getTime());

      const blockedTimes = [...busyTimes];
      for (const pause of pauses) {
        const [pauseStartHour, pauseStartMin] = pause.start.split(':').map(Number);
        const [pauseEndHour, pauseEndMin] = pause.end.split(':').map(Number);
        const pauseStart = setMinutes(setHours(currentDate, pauseStartHour), pauseStartMin);
        const pauseEnd = setMinutes(setHours(currentDate, pauseEndHour), pauseEndMin);
        blockedTimes.push({ start: pauseStart, end: pauseEnd });
      }

      blockedTimes.sort((a, b) => a.start.getTime() - b.start.getTime());

      let searchTime = searchStart;
      for (const blocked of blockedTimes) {
        const gapDuration = Math.floor(
          (blocked.start.getTime() - searchTime.getTime()) / 60000
        );
        if (gapDuration >= requiredDuration) {
          const slotEnd = addMinutesDateFns(searchTime, requiredDuration);
          return { start: searchTime, end: slotEnd };
        }
        searchTime = blocked.end;
      }

      const finalGapDuration = Math.floor(
        (dayEnd.getTime() - searchTime.getTime()) / 60000
      );
      if (finalGapDuration >= requiredDuration) {
        const slotEnd = addMinutesDateFns(searchTime, requiredDuration);
        return { start: searchTime, end: slotEnd };
      }
    }

    currentDate = addDays(currentDate, 1);
  }

  return null;
}

/**
 * Agenda automaticamente as tarefas elegíveis
 */
export function autoScheduleTasks(
  tasks: Task[],
  profiles: Map<string, TimeProfile>,
  existingSlots: Slot[],
  now: Date = new Date()
): SchedulingResult {
  const result: SchedulingResult = {
    slots: [],
    unscheduledTaskIds: [],
    errors: [],
  };

  const eligibleTasks = tasks
    .filter((t) => isTaskEligibleForScheduling(t, now))
    .sort((a, b) => {
      const priorityOrder = { urgent: 4, high: 3, medium: 2, low: 1 };
      const aPriority = priorityOrder[a.priority] || 0;
      const bPriority = priorityOrder[b.priority] || 0;

      if (a.deadline && b.deadline) {
        const aDeadline = parseISO(a.deadline).getTime();
        const bDeadline = parseISO(b.deadline).getTime();
        if (aDeadline !== bDeadline) return aDeadline - bDeadline;
      } else if (a.deadline) {
        return -1;
      } else if (b.deadline) {
        return 1;
      }

      return bPriority - aPriority;
    });

  for (const task of eligibleTasks) {
    const profile = task.profileId
      ? profiles.get(task.profileId)
      : Array.from(profiles.values())[0];

    if (!profile) {
      result.errors.push(`Tarefa "${task.name}" sem perfil válido`);
      result.unscheduledTaskIds.push(task.id);
      continue;
    }

    const taskOccurrences =
      task.repeat !== 'none'
        ? generateRecurrenceOccurrences(task, now)
        : [task];

    for (const occurrence of taskOccurrences) {
      const availableSlot = findNextAvailableSlot(
        profile,
        [...existingSlots, ...result.slots],
        occurrence.duration,
        now
      );

      if (availableSlot) {
        const newSlots = dividableTaskToSlots(occurrence, availableSlot.start);
        result.slots.push(...newSlots);
      } else {
        result.unscheduledTaskIds.push(occurrence.id);
      }
    }
  }

  return result;
}
