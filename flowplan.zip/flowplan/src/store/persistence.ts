import { openDB, DBSchema, IDBPDatabase } from 'idb';
import { Task, Project, Tag, TimeProfile, Slot } from './types';

interface FlowPlanDB extends DBSchema {
  tasks: {
    key: string;
    value: Task;
  };
  projects: {
    key: string;
    value: Project;
  };
  tags: {
    key: string;
    value: Tag;
  };
  profiles: {
    key: string;
    value: TimeProfile;
  };
  slots: {
    key: string;
    value: Slot;
  };
}

let db: IDBPDatabase<FlowPlanDB> | null = null;

export async function initDB(): Promise<IDBPDatabase<FlowPlanDB>> {
  if (db) return db;

  db = await openDB<FlowPlanDB>('flowplan-db', 1, {
    upgrade(db) {
      if (!db.objectStoreNames.contains('tasks')) {
        db.createObjectStore('tasks', { keyPath: 'id' });
      }
      if (!db.objectStoreNames.contains('projects')) {
        db.createObjectStore('projects', { keyPath: 'id' });
      }
      if (!db.objectStoreNames.contains('tags')) {
        db.createObjectStore('tags', { keyPath: 'id' });
      }
      if (!db.objectStoreNames.contains('profiles')) {
        db.createObjectStore('profiles', { keyPath: 'id' });
      }
      if (!db.objectStoreNames.contains('slots')) {
        db.createObjectStore('slots', { keyPath: 'id' });
      }
    },
  });

  return db;
}

// Tasks
export async function addTaskDB(task: Task): Promise<void> {
  const db = await initDB();
  await db.put('tasks', task);
}

export async function updateTaskDB(id: string, updates: Partial<Task>): Promise<void> {
  const db = await initDB();
  const task = await db.get('tasks', id);
  if (task) {
    await db.put('tasks', { ...task, ...updates });
  }
}

export async function deleteTaskDB(id: string): Promise<void> {
  const db = await initDB();
  await db.delete('tasks', id);
  // Delete associated slots
  const slots = await db.getAll('slots');
  for (const slot of slots) {
    if (slot.taskId === id) {
      await db.delete('slots', slot.id);
    }
  }
}

export async function getTaskDB(id: string): Promise<Task | undefined> {
  const db = await initDB();
  return db.get('tasks', id);
}

export async function getAllTasksDB(): Promise<Task[]> {
  const db = await initDB();
  return db.getAll('tasks');
}

// Slots
export async function addSlotDB(slot: Slot): Promise<void> {
  const db = await initDB();
  await db.put('slots', slot);
}

export async function deleteSlotDB(id: string): Promise<void> {
  const db = await initDB();
  await db.delete('slots', id);
}

export async function deleteSlotsByTaskDB(taskId: string): Promise<void> {
  const db = await initDB();
  const slots = await db.getAll('slots');
  for (const slot of slots) {
    if (slot.taskId === taskId) {
      await db.delete('slots', slot.id);
    }
  }
}

export async function getSlotsByTaskDB(taskId: string): Promise<Slot[]> {
  const db = await initDB();
  const slots = await db.getAll('slots');
  return slots.filter(s => s.taskId === taskId);
}

export async function getAllSlotsDB(): Promise<Slot[]> {
  const db = await initDB();
  return db.getAll('slots');
}

export async function updateSlotDB(id: string, updates: Partial<Slot>): Promise<void> {
  const db = await initDB();
  const slot = await db.get('slots', id);
  if (slot) {
    await db.put('slots', { ...slot, ...updates });
  }
}

// Projects
export async function addProjectDB(project: Project): Promise<void> {
  const db = await initDB();
  await db.put('projects', project);
}

export async function updateProjectDB(id: string, updates: Partial<Project>): Promise<void> {
  const db = await initDB();
  const project = await db.get('projects', id);
  if (project) {
    await db.put('projects', { ...project, ...updates });
  }
}

export async function deleteProjectDB(id: string): Promise<void> {
  const db = await initDB();
  await db.delete('projects', id);
}

export async function getAllProjectsDB(): Promise<Project[]> {
  const db = await initDB();
  return db.getAll('projects');
}

// Tags
export async function addTagDB(tag: Tag): Promise<void> {
  const db = await initDB();
  await db.put('tags', tag);
}

export async function updateTagDB(id: string, updates: Partial<Tag>): Promise<void> {
  const db = await initDB();
  const tag = await db.get('tags', id);
  if (tag) {
    await db.put('tags', { ...tag, ...updates });
  }
}

export async function deleteTagDB(id: string): Promise<void> {
  const db = await initDB();
  await db.delete('tags', id);
}

export async function getAllTagsDB(): Promise<Tag[]> {
  const db = await initDB();
  return db.getAll('tags');
}

// Profiles
export async function addProfileDB(profile: TimeProfile): Promise<void> {
  const db = await initDB();
  await db.put('profiles', profile);
}

export async function updateProfileDB(id: string, updates: Partial<TimeProfile>): Promise<void> {
  const db = await initDB();
  const profile = await db.get('profiles', id);
  if (profile) {
    await db.put('profiles', { ...profile, ...updates });
  }
}

export async function deleteProfileDB(id: string): Promise<void> {
  const db = await initDB();
  await db.delete('profiles', id);
}

export async function getAllProfilesDB(): Promise<TimeProfile[]> {
  const db = await initDB();
  return db.getAll('profiles');
}

// Bulk operations
export async function importBackupDB(
  tasks: Task[],
  projects: Project[],
  tags: Tag[],
  profiles: TimeProfile[],
  slots: Slot[]
): Promise<void> {
  const db = await initDB();
  
  const tx = db.transaction(['tasks', 'projects', 'tags', 'profiles', 'slots'], 'readwrite');
  
  // Clear existing data
  await tx.objectStore('tasks').clear();
  await tx.objectStore('projects').clear();
  await tx.objectStore('tags').clear();
  await tx.objectStore('profiles').clear();
  await tx.objectStore('slots').clear();
  
  // Add new data
  for (const task of tasks) {
    await tx.objectStore('tasks').put(task);
  }
  for (const project of projects) {
    await tx.objectStore('projects').put(project);
  }
  for (const tag of tags) {
    await tx.objectStore('tags').put(tag);
  }
  for (const profile of profiles) {
    await tx.objectStore('profiles').put(profile);
  }
  for (const slot of slots) {
    await tx.objectStore('slots').put(slot);
  }
  
  await tx.done;
}

export async function exportBackupDB(): Promise<{
  tasks: Task[];
  projects: Project[];
  tags: Tag[];
  profiles: TimeProfile[];
  slots: Slot[];
}> {
  const db = await initDB();
  
  return {
    tasks: await db.getAll('tasks'),
    projects: await db.getAll('projects'),
    tags: await db.getAll('tags'),
    profiles: await db.getAll('profiles'),
    slots: await db.getAll('slots'),
  };
}
