import { create } from 'zustand';
import { v4 as uuidv4 } from 'uuid';
import { AppState, Task, Project, Tag, TimeProfile, Slot } from './types';
import {
  initDB,
  addTaskDB,
  updateTaskDB,
  deleteTaskDB,
  getAllTasksDB,
  addProjectDB,
  updateProjectDB,
  deleteProjectDB,
  getAllProjectsDB,
  addTagDB,
  updateTagDB,
  deleteTagDB,
  getAllTagsDB,
  addProfileDB,
  updateProfileDB,
  deleteProfileDB,
  getAllProfilesDB,
  addSlotDB,
  updateSlotDB,
  deleteSlotDB,
  deleteSlotsByTaskDB,
  getAllSlotsDB,
  importBackupDB,
  exportBackupDB,
} from './persistence';
import {
  autoScheduleTasks,
  isTaskEligibleForScheduling,
  calculateTaskStatus,
} from './scheduler';

const defaultProfile: TimeProfile = {
  id: uuidv4(),
  name: 'Padrão',
  interval: 5,
  standardStart: '08:00',
  standardEnd: '18:00',
  standardPauses: [],
  days: {
    0: { active: false, type: 'standard' },
    1: { active: true, type: 'standard' },
    2: { active: true, type: 'standard' },
    3: { active: true, type: 'standard' },
    4: { active: true, type: 'standard' },
    5: { active: true, type: 'standard' },
    6: { active: false, type: 'standard' },
  },
};

const defaultTags = [
  { id: uuidv4(), name: 'Trabalho', color: '#3b82f6' },
  { id: uuidv4(), name: 'Pessoal', color: '#10b981' },
  { id: uuidv4(), name: 'Estudo', color: '#f59e0b' },
];

// Inicializa o DB com dados padrão se estiver vazio
async function initializeDB() {
  try {
    await initDB();
    const existingTasks = await getAllTasksDB();
    
    if (existingTasks.length === 0) {
      // Primeira vez: inicializa com dados padrão
      await addProfileDB(defaultProfile);
      for (const tag of defaultTags) {
        await addTagDB(tag);
      }
    }
  } catch (error) {
    console.error('Erro ao inicializar DB:', error);
  }
}

// Inicia a inicialização
initializeDB();

export const useStore = create<AppState>((set, get) => ({
  tasks: [],
  slots: [],
  projects: [],
  tags: defaultTags,
  profiles: [defaultProfile],

  // Carrega dados do IndexedDB
  loadFromDB: async () => {
    try {
      const [tasks, projects, tags, profiles, slots] = await Promise.all([
        getAllTasksDB(),
        getAllProjectsDB(),
        getAllTagsDB(),
        getAllProfilesDB(),
        getAllSlotsDB(),
      ]);

      // Calcula status de atraso para todas as tarefas
      const now = new Date();
      for (const task of tasks) {
        calculateTaskStatus(task, now);
      }

      set({ tasks, projects, tags, profiles, slots });
    } catch (error) {
      console.error('Erro ao carregar dados do DB:', error);
    }
  },

  // Tasks
  addTask: (taskData) => {
    const task: Task = {
      ...taskData,
      id: uuidv4(),
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
      status: taskData.status || 'pending',
    };

    addTaskDB(task);

    set((state) => {
      const newTasks = [...state.tasks, task];

      // Auto-schedule se elegível
      if (isTaskEligibleForScheduling(task)) {
        const profileMap = new Map(state.profiles.map((p) => [p.id, p]));
        const result = autoScheduleTasks(
          [task],
          profileMap,
          state.slots  
        );

        // Salva slots
        for (const slot of result.slots) {
          addSlotDB(slot);
        }

        // Atualiza task se foi agendada
        if (result.slots.length > 0) {
          const updatedTask = { ...task, isPlanned: true, status: 'scheduled' as const };
          updateTaskDB(updatedTask.id, updatedTask);
          return {
            tasks: newTasks.map((t) => (t.id === task.id ? updatedTask : t)),
            slots: [...state.slots, ...result.slots],
          };
        }
      }

      return { tasks: newTasks };
    });
  },

  updateTask: (id, updates) => {
    set((state) => {
      const task = state.tasks.find((t) => t.id === id);
      if (!task) return state;

      const updatedTask = {
        ...task,
        ...updates,
        updatedAt: new Date().toISOString(),
      };

      updateTaskDB(id, updatedTask);

      // Se mudou estado importante, recalcula agendamento
      if (
        updates.status ||
        updates.deadline ||
        updates.duration ||
        updates.divisible ||
        updates.profileId
      ) {
        calculateTaskStatus(updatedTask);

        // Se foi marcada como concluída, remove slots
        if (updates.status === 'completed') {
          deleteSlotsByTaskDB(id);
          return {
            tasks: state.tasks.map((t) => (t.id === id ? updatedTask : t)),
            slots: state.slots.filter((s) => s.taskId !== id),
          };
        }

        // Se mudou de um estado agendável, tenta reagendar
        if (
          isTaskEligibleForScheduling(updatedTask) &&
          updates.status
        ) {
          // Remove slots antigos
          deleteSlotsByTaskDB(id);
          const profileMap = new Map(state.profiles.map((p) => [p.id, p]));
          const result = autoScheduleTasks(
            [updatedTask],
            profileMap,
            state.slots.filter((s) => s.taskId !== id)
          );

          if (result.slots.length > 0) {
            for (const slot of result.slots) {
              addSlotDB(slot);
            }
            const finalTask = { ...updatedTask, isPlanned: true, status: 'scheduled' as const };
            updateTaskDB(id, finalTask);
            return {
              tasks: state.tasks.map((t) => (t.id === id ? finalTask : t)),
              slots: state.slots
                .filter((s) => s.taskId !== id)
                .concat(result.slots),
            };
          }
        }
      }

      return {
        tasks: state.tasks.map((t) => (t.id === id ? updatedTask : t)),
      };
    });
  },

  deleteTask: (id) => {
    deleteTaskDB(id);
    deleteSlotsByTaskDB(id);

    set((state) => ({
      tasks: state.tasks.filter((t) => t.id !== id),
      slots: state.slots.filter((s) => s.taskId !== id),
    }));
  },

  addProject: (project) => {
    const newProject: Project = {
      ...project,
      id: uuidv4(),
    };
    addProjectDB(newProject);
    set((state) => ({ projects: [...state.projects, newProject] }));
  },

  updateProject: (id, updates) => {
    updateProjectDB(id, updates);
    set((state) => ({
      projects: state.projects.map((p) =>
        p.id === id ? { ...p, ...updates } : p
      ),
    }));
  },

  deleteProject: (id) => {
    deleteProjectDB(id);
    set((state) => ({
      projects: state.projects.filter((p) => p.id !== id),
      tasks: state.tasks.map((t) =>
        t.projectId === id ? { ...t, projectId: undefined } : t
      ),
    }));
  },

  addTag: (tag) => {
    const newTag: Tag = {
      ...tag,
      id: uuidv4(),
    };
    addTagDB(newTag);
    set((state) => ({ tags: [...state.tags, newTag] }));
  },

  updateTag: (id, updates) => {
    updateTagDB(id, updates);
    set((state) => ({
      tags: state.tags.map((t) => (t.id === id ? { ...t, ...updates } : t)),
    }));
  },

  deleteTag: (id) => {
    deleteTagDB(id);
    set((state) => ({
      tags: state.tags.filter((t) => t.id !== id),
      tasks: state.tasks.map((t) =>
        t.tagId === id ? { ...t, tagId: undefined } : t
      ),
      projects: state.projects.map((p) =>
        p.tagId === id ? { ...p, tagId: undefined } : p
      ),
    }));
  },

  addProfile: (profile) => {
    const newProfile: TimeProfile = {
      ...profile,
      id: uuidv4(),
    };
    addProfileDB(newProfile);
    set((state) => ({ profiles: [...state.profiles, newProfile] }));
  },

  updateProfile: (id, updates) => {
    updateProfileDB(id, updates);
    set((state) => ({
      profiles: state.profiles.map((p) =>
        p.id === id ? { ...p, ...updates } : p
      ),
    }));
  },

  deleteProfile: (id) => {
    deleteProfileDB(id);
    set((state) => ({
      profiles: state.profiles.filter((p) => p.id !== id),
    }));
  },

  // Slots
  addSlot: (slot) => {
    addSlotDB(slot);
    set((state) => ({
      slots: [...state.slots, slot],
      tasks: state.tasks.map((t) =>
        t.id === slot.taskId ? { ...t, isPlanned: true } : t
      ),
    }));
  },

  updateSlot: (id, updates) => {
    updateSlotDB(id, updates);
    set((state) => ({
      slots: state.slots.map((s) =>
        s.id === id ? { ...s, ...updates } : s
      ),
    }));
  },

  deleteSlot: (id) => {
    deleteSlotDB(id);
    set((state) => {
      const slot = state.slots.find((s) => s.id === id);
      return {
        slots: state.slots.filter((s) => s.id !== id),
        tasks: state.tasks.map((t) =>
          t.id === slot?.taskId
            ? {
                ...t,
                isPlanned: state.slots.filter(
                  (s) => s.taskId === t.id && s.id !== id
                ).length > 0,
              }
            : t
        ),
      };
    });
  },

  // Auto-scheduler
  autoSchedule: () => {
    set((state) => {
      const profileMap = new Map(state.profiles.map((p) => [p.id, p]));
      const result = autoScheduleTasks(
        state.tasks,
        profileMap,
        state.slots
      );

      // Salva novos slots
      for (const slot of result.slots) {
        addSlotDB(slot);
      }

      // Atualiza tarefas agendadas
      const updatedTasks = state.tasks.map((t) => {
        if (result.slots.some((s) => s.taskId === t.id)) {
          updateTaskDB(t.id, { isPlanned: true, status: 'scheduled' });
          return { ...t, isPlanned: true, status: 'scheduled' as const };
        }
        return t;
      });

      return {
        tasks: updatedTasks,
        slots: [...state.slots, ...result.slots],
      };
    });
  },

  exportBackup: () => {
    const state = get();
    return JSON.stringify({
      tasks: state.tasks,
      projects: state.projects,
      tags: state.tags,
      profiles: state.profiles,
      slots: state.slots,
    });
  },

  importBackup: async (data) => {
    try {
      const parsed = JSON.parse(data);
      if (
        parsed.tasks &&
        parsed.projects &&
        parsed.tags &&
        parsed.profiles &&
        parsed.slots
      ) {
        await importBackupDB(
          parsed.tasks,
          parsed.projects,
          parsed.tags,
          parsed.profiles,
          parsed.slots
        );
        set({
          tasks: parsed.tasks,
          projects: parsed.projects,
          tags: parsed.tags,
          profiles: parsed.profiles,
          slots: parsed.slots,
        });
      }
    } catch (e) {
      console.error('Invalid backup file:', e);
      throw new Error('Invalid backup file');
    }
  },
}));
