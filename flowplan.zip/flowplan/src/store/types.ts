export type Priority = 'low' | 'medium' | 'high' | 'urgent';
export type TaskStatus = 'pending' | 'completed' | 'blocked' | 'delayed' | 'scheduled' | 'no-time';
export type RepeatType = 'none' | 'daily' | 'weekly' | 'monthly';

export interface Pause {
  id: string;
  start: string; // HH:mm
  end: string;   // HH:mm
  label?: string;
}

export interface DayConfig {
  active: boolean;
  type: 'standard' | 'custom';
  start?: string;
  end?: string;
  pauses?: Pause[];
}

export interface TimeProfile {
  id: string;
  name: string;
  interval: number; // minutes
  standardStart: string; // HH:mm
  standardEnd: string; // HH:mm
  standardPauses: Pause[];
  days: { [key: number]: DayConfig }; // 0 = Sunday, 1 = Monday, etc.
}

export interface Tag {
  id: string;
  name: string;
  color: string;
}

export interface Project {
  id: string;
  name: string;
  description: string;
  deadline?: string; // ISO date string
  tagId?: string;
  profileId?: string;
}

export interface Subtask {
  id: string;
  title: string;
  completed: boolean;
}

export interface Slot {
  id: string;
  taskId: string;
  start: string; // ISO string
  end: string; // ISO string
  isFixed: boolean; // true if from fixedStart/fixedEnd
  createdAt: string; // ISO string
  recurrenceDate?: string; // ISO date for recurring tasks
}

export interface Task {
  id: string;
  name: string;
  description?: string; // NEW: Task description
  duration: number; // in minutes
  priority: Priority;
  tagId?: string;
  projectId?: string;
  profileId?: string;
  deadline?: string; // ISO date
  deadlineTime?: string; // NEW: HH:mm format for maximum time
  availableFrom?: string; // ISO date
  timeRestrictionStart?: string; // HH:mm
  timeRestrictionEnd?: string; // HH:mm
  buffer: number; // in minutes
  isFixed: boolean;
  fixedStart?: string; // ISO string
  fixedEnd?: string; // ISO string
  repeat: RepeatType;
  repeatInterval?: number; // interval for repeat (days for daily, weeks for weekly)
  repeatDays?: number[]; // days of week for weekly repeat (0=Sun, 1=Mon, etc.)
  divisible: boolean;
  minSession?: number; // minimum session duration for divisible tasks
  dependencies: string[]; // Task IDs
  subtasks: Subtask[];
  status: TaskStatus;
  isPinned: boolean;
  isPlanned: boolean; // whether has scheduled slot
  scheduledStart?: string; // ISO string (DEPRECATED - use slots instead)
  scheduledEnd?: string; // ISO string (DEPRECATED - use slots instead)
  createdAt: string; // ISO string
  updatedAt: string; // ISO string
}

export interface AppState {
  tasks: Task[];
  slots: Slot[];
  projects: Project[];
  tags: Tag[];
  profiles: TimeProfile[];
  
  // Load from DB
  loadFromDB: () => Promise<void>;
  
  // Task actions
  addTask: (task: Omit<Task, 'id' | 'createdAt' | 'updatedAt'>) => void;
  updateTask: (id: string, updates: Partial<Task>) => void;
  deleteTask: (id: string) => void;
  
  // Slot actions
  addSlot: (slot: Slot) => void;
  updateSlot: (id: string, updates: Partial<Slot>) => void;
  deleteSlot: (id: string) => void;
  
  // Project actions
  addProject: (project: Omit<Project, 'id'>) => void;
  updateProject: (id: string, updates: Partial<Project>) => void;
  deleteProject: (id: string) => void;
  
  // Tag actions
  addTag: (tag: Omit<Tag, 'id'>) => void;
  updateTag: (id: string, updates: Partial<Tag>) => void;
  deleteTag: (id: string) => void;
  
  // Profile actions
  addProfile: (profile: Omit<TimeProfile, 'id'>) => void;
  updateProfile: (id: string, updates: Partial<TimeProfile>) => void;
  deleteProfile: (id: string) => void;
  
  // Backup/Import
  exportBackup: () => string;
  importBackup: (data: string) => Promise<void>;
  
  // Auto planner
  autoSchedule: () => void;
}
