import { useState, useMemo } from 'react';
import { useStore } from '../store/useStore';
import { Search, Filter, ArrowUpDown, ChevronDown, ChevronRight, Clock, Calendar, CheckCircle, Tag as TagIcon, MoreVertical } from 'lucide-react';
import { format, parseISO } from 'date-fns';
import { Task, Project } from '../store/types';

type SortOption = 'deadline' | 'priority' | 'alphabetical' | 'createdAt';

export default function TasksTab() {
  const { tasks, projects, tags, updateTask } = useStore();
  
  const [search, setSearch] = useState('');
  const [sortBy, setSortBy] = useState<SortOption>('createdAt');
  const [sortDesc, setSortDesc] = useState(false);
  
  const [showFilters, setShowFilters] = useState(false);
  const [filterStatus, setFilterStatus] = useState<string>('all');
  const [filterTag, setFilterTag] = useState<string>('all');
  const [filterProject, setFilterProject] = useState<string>('all');

  const [expandedProjects, setExpandedProjects] = useState<Record<string, boolean>>({ 'no-project': true });
  const [editingTaskId, setEditingTaskId] = useState<string | null>(null);

  const toggleProject = (id: string) => {
    setExpandedProjects(prev => ({ ...prev, [id]: !prev[id] }));
  };

  const filteredTasks = useMemo(() => {
    return tasks.filter(task => {
      // Search
      const searchLower = search.toLowerCase();
      if (search && !task.name.toLowerCase().includes(searchLower)) {
        return false;
      }
      
      // Filters
      if (filterStatus !== 'all' && task.status !== filterStatus) return false;
      if (filterTag !== 'all' && task.tagId !== filterTag) return false;
      if (filterProject !== 'all' && (task.projectId || 'no-project') !== filterProject) return false;
      
      return true;
    }).sort((a, b) => {
      let comparison = 0;
      if (sortBy === 'alphabetical') {
        comparison = a.name.localeCompare(b.name);
      } else if (sortBy === 'deadline') {
        const da = a.deadline ? new Date(a.deadline).getTime() : Infinity;
        const db = b.deadline ? new Date(b.deadline).getTime() : Infinity;
        comparison = da - db;
      } else if (sortBy === 'priority') {
        const priorityOrder = { urgent: 4, high: 3, medium: 2, low: 1 };
        comparison = (priorityOrder[b.priority] || 0) - (priorityOrder[a.priority] || 0);
      }
      // Since we don't store createdAt, we use ID as fallback for deterministic order
      if (comparison === 0) {
        comparison = a.id.localeCompare(b.id);
      }
      return sortDesc ? -comparison : comparison;
    });
  }, [tasks, search, filterStatus, filterTag, filterProject, sortBy, sortDesc]);

  // Group by project
  const groupedTasks = useMemo(() => {
    const groups: Record<string, Task[]> = { 'no-project': [] };
    projects.forEach(p => groups[p.id] = []);
    
    filteredTasks.forEach(task => {
      const pid = task.projectId || 'no-project';
      if (groups[pid]) {
        groups[pid].push(task);
      } else {
        groups['no-project'].push(task);
      }
    });
    return groups;
  }, [filteredTasks, projects]);

  const toggleTaskStatus = (task: Task) => {
    updateTask(task.id, { 
      status: task.status === 'completed' ? 'pending' : 'completed' 
    });
  };

  const clearFilters = () => {
    setFilterStatus('all');
    setFilterTag('all');
    setFilterProject('all');
    setSearch('');
  };

  return (
    <div className="flex flex-col h-full bg-gray-50">
      <div className="sticky top-0 bg-white z-10 px-4 py-3 border-b border-gray-200 shadow-sm">
        <h1 className="text-xl font-bold text-gray-800 mb-3">Tarefas</h1>
        
        <div className="flex gap-2 mb-3">
          <div className="relative flex-1">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 text-gray-400" size={18} />
            <input 
              type="text" 
              placeholder="Buscar tarefas..."
              value={search}
              onChange={(e) => setSearch(e.target.value)}
              className="w-full bg-gray-100 border-none rounded-lg pl-10 pr-4 py-2 text-sm focus:ring-2 focus:ring-blue-500 outline-none transition-shadow"
            />
          </div>
          <button 
            onClick={() => setShowFilters(!showFilters)}
            className={`p-2 rounded-lg flex items-center justify-center transition-colors ${showFilters || filterStatus !== 'all' || filterTag !== 'all' || filterProject !== 'all' ? 'bg-blue-100 text-blue-700' : 'bg-gray-100 text-gray-600 hover:bg-gray-200'}`}
          >
            <Filter size={18} />
          </button>
        </div>

        {showFilters && (
          <div className="bg-white border border-gray-200 rounded-lg p-3 mb-3 shadow-sm text-sm">
            <div className="grid grid-cols-2 gap-3 mb-3">
              <div>
                <label className="block text-xs font-medium text-gray-600 mb-1">Status</label>
                <select value={filterStatus} onChange={e => setFilterStatus(e.target.value)} className="w-full bg-gray-50 border border-gray-200 rounded px-2 py-1.5 outline-none">
                  <option value="all">Todos</option>
                  <option value="pending">Pendente</option>
                  <option value="completed">Concluída</option>
                  <option value="scheduled">Agendada</option>
                  <option value="no-time">Sem horário</option>
                </select>
              </div>
              <div>
                <label className="block text-xs font-medium text-gray-600 mb-1">Tag</label>
                <select value={filterTag} onChange={e => setFilterTag(e.target.value)} className="w-full bg-gray-50 border border-gray-200 rounded px-2 py-1.5 outline-none">
                  <option value="all">Todas</option>
                  {tags.map(t => <option key={t.id} value={t.id}>{t.name}</option>)}
                </select>
              </div>
            </div>
            <div className="flex justify-between items-center">
              <button onClick={clearFilters} className="text-xs text-blue-600 hover:underline">
                Limpar filtros
              </button>
              
              <div className="flex items-center gap-2">
                <span className="text-xs font-medium text-gray-600">Ordenar por:</span>
                <select value={sortBy} onChange={e => setSortBy(e.target.value as SortOption)} className="bg-gray-50 border border-gray-200 rounded px-2 py-1 outline-none text-xs">
                  <option value="deadline">Prazo</option>
                  <option value="priority">Prioridade</option>
                  <option value="alphabetical">Alfabética</option>
                  <option value="createdAt">Criação</option>
                </select>
                <button onClick={() => setSortDesc(!sortDesc)} className="p-1 bg-gray-100 rounded text-gray-600">
                  <ArrowUpDown size={14} />
                </button>
              </div>
            </div>
          </div>
        )}
      </div>

      <div className="p-4 overflow-y-auto flex-1 pb-24 space-y-4">
        {/* No Project */}
        {groupedTasks['no-project'].length > 0 && (
          <div className="bg-white rounded-xl shadow-sm border border-gray-100 overflow-hidden">
            <button 
              onClick={() => toggleProject('no-project')}
              className="w-full flex items-center justify-between p-3 bg-gray-50 hover:bg-gray-100 transition-colors"
            >
              <h2 className="font-semibold text-gray-700 flex items-center gap-2">
                Sem projeto <span className="bg-gray-200 text-gray-600 text-xs px-2 py-0.5 rounded-full">{groupedTasks['no-project'].length}</span>
              </h2>
              {expandedProjects['no-project'] ? <ChevronDown size={18} className="text-gray-500"/> : <ChevronRight size={18} className="text-gray-500"/>}
            </button>
            
            {expandedProjects['no-project'] && (
              <div className="divide-y divide-gray-100">
                {groupedTasks['no-project'].map(task => (
                  <TaskCard 
                    key={task.id} 
                    task={task} 
                    onToggle={(e) => { e.stopPropagation(); toggleTaskStatus(task); }} 
                    onClick={() => setEditingTaskId(task.id)}
                  />
                ))}
              </div>
            )}
          </div>
        )}

        {/* Projects */}
        {projects.map(project => {
          const projectTasks = groupedTasks[project.id] || [];
          if (projectTasks.length === 0 && filterStatus !== 'all') return null; // hide empty projects if filtering
          
          const isExpanded = expandedProjects[project.id] ?? true; // default expanded

          return (
            <div key={project.id} className="bg-white rounded-xl shadow-sm border border-gray-100 overflow-hidden">
              <button 
                onClick={() => toggleProject(project.id)}
                className="w-full flex items-center justify-between p-3 bg-gray-50 hover:bg-gray-100 transition-colors border-b border-gray-100"
              >
                <div className="flex items-center gap-2">
                  <div className="w-3 h-3 rounded-full" style={{ backgroundColor: tags.find(t => t.id === project.tagId)?.color || '#cbd5e1' }} />
                  <h2 className="font-semibold text-gray-700">{project.name}</h2>
                  <span className="bg-gray-200 text-gray-600 text-xs px-2 py-0.5 rounded-full">{projectTasks.length}</span>
                </div>
                {isExpanded ? <ChevronDown size={18} className="text-gray-500"/> : <ChevronRight size={18} className="text-gray-500"/>}
              </button>
              
              {isExpanded && (
                <div className="divide-y divide-gray-100">
                  {projectTasks.length === 0 ? (
                    <div className="p-4 text-center text-sm text-gray-500 italic">Nenhuma tarefa neste projeto.</div>
                  ) : (
                    projectTasks.map(task => (
                      <TaskCard 
                        key={task.id} 
                        task={task} 
                        onToggle={(e) => { e.stopPropagation(); toggleTaskStatus(task); }} 
                        onClick={() => setEditingTaskId(task.id)}
                      />
                    ))
                  )}
                </div>
              )}
            </div>
          );
        })}
        
        {tasks.length === 0 && (
          <div className="flex flex-col items-center justify-center py-12 px-4 text-center">
            <div className="w-16 h-16 bg-gray-100 rounded-full flex items-center justify-center text-gray-400 mb-4">
              <CheckCircle size={32} />
            </div>
            <h3 className="text-lg font-medium text-gray-800 mb-1">Nenhuma tarefa</h3>
            <p className="text-sm text-gray-500">Toque no botão + para criar sua primeira tarefa.</p>
          </div>
        )}
      </div>

      {editingTaskId && (
        <TaskModal 
          taskId={editingTaskId} 
          onClose={() => setEditingTaskId(null)} 
        />
      )}
    </div>
  );
}

import TaskModal from '../components/TaskModal';

function TaskCard({ task, onToggle, onClick }: { task: Task, onToggle: (e: React.MouseEvent) => void, onClick: () => void }) {
  const { tags } = useStore();  const tag = tags.find(t => t.id === task.tagId);
  const isCompleted = task.status === 'completed';

  const priorityColors = {
    low: 'bg-gray-100 text-gray-600',
    medium: 'bg-blue-100 text-blue-700',
    high: 'bg-orange-100 text-orange-700',
    urgent: 'bg-red-100 text-red-700'
  };

  const priorityLabels = {
    low: 'Baixa',
    medium: 'Média',
    high: 'Alta',
    urgent: 'Urgente'
  };

  return (
    <div 
      className={`p-3 hover:bg-gray-50 flex items-start gap-3 transition-colors cursor-pointer ${isCompleted ? 'opacity-60' : ''}`}
      onClick={onClick}
    >
      <button 
        onClick={onToggle}
        className={`mt-1 shrink-0 w-5 h-5 rounded-full border flex items-center justify-center transition-colors ${isCompleted ? 'bg-green-500 border-green-500 text-white' : 'border-gray-300 hover:border-green-500 hover:bg-green-50'}`}
      >
        {isCompleted && <CheckCircle size={14} className="stroke-[3]" />}
      </button>
      
      <div className="flex-1 min-w-0">
        <h3 className={`font-medium text-sm truncate ${isCompleted ? 'line-through text-gray-500' : 'text-gray-800'}`}>
          {task.name}
        </h3>
        
        <div className="flex flex-wrap items-center gap-2 mt-1.5 text-xs text-gray-500">
          <span className="flex items-center gap-1">
            <Clock size={12} /> {task.duration} min
          </span>
          
          {task.deadline && (
            <span className="flex items-center gap-1 text-orange-600 bg-orange-50 px-1.5 py-0.5 rounded">
              <Calendar size={12} /> {format(parseISO(task.deadline), 'dd/MM/yyyy')}
            </span>
          )}

          <span className={`px-1.5 py-0.5 rounded ${priorityColors[task.priority]}`}>
            {priorityLabels[task.priority]}
          </span>
          
          {tag && (
            <span className="flex items-center gap-1" style={{ color: tag.color }}>
              <TagIcon size={12} /> {tag.name}
            </span>
          )}
        </div>
      </div>
      
      <button className="p-1 text-gray-400 hover:text-gray-600 rounded">
        <MoreVertical size={16} />
      </button>
    </div>
  );
}
