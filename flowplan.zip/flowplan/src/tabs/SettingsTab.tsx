import { useState } from 'react';
import { useStore } from '../store/useStore';
import { Settings2, Tag as TagIcon, Database, ChevronDown, ChevronRight, Plus, Edit, Trash2 } from 'lucide-react';
import TagModal from '../components/TagModal';
import ProfileModal from '../components/ProfileModal';

export default function SettingsTab() {
  const [openSection, setOpenSection] = useState<'profiles' | 'tags' | 'data' | null>('profiles');
  const { tags, profiles, deleteTag, deleteProfile, exportBackup, importBackup } = useStore();

  const [editingTagId, setEditingTagId] = useState<string | null>(null);
  const [isTagModalOpen, setIsTagModalOpen] = useState(false);

  const [editingProfileId, setEditingProfileId] = useState<string | null>(null);
  const [isProfileModalOpen, setIsProfileModalOpen] = useState(false);

  const handleExport = () => {
    const data = exportBackup();
    const blob = new Blob([data], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = 'flowplan-backup.json';
    a.click();
    URL.revokeObjectURL(url);
  };

  const handleImport = async () => {
    const input = document.createElement('input');
    input.type = 'file';
    input.accept = 'application/json';
    input.onchange = async (e) => {
      const file = (e.target as HTMLInputElement).files?.[0];
      if (file) {
        const reader = new FileReader();
        reader.onload = async (event) => {
          try {
            await importBackup(event.target?.result as string);
            alert('Backup importado com sucesso!');
          } catch (error) {
            alert('Erro ao importar backup. Arquivo inválido.');
          }
        };
        reader.readAsText(file);
      }
    };
    input.click();
  };

  return (
    <div className="p-4 max-w-2xl mx-auto">
      <h1 className="text-2xl font-bold mb-6 text-gray-800">Ajustes</h1>

      {/* Profiles Section */}
      <div className="bg-white rounded-lg shadow-sm mb-4 border border-gray-100 overflow-hidden">
        <button 
          className="w-full flex items-center justify-between p-4 bg-gray-50 hover:bg-gray-100 transition-colors"
          onClick={() => setOpenSection(openSection === 'profiles' ? null : 'profiles')}
        >
          <div className="flex items-center gap-2">
            <Settings2 size={20} className="text-blue-600" />
            <h2 className="text-lg font-semibold text-gray-700">Perfis de horário</h2>
          </div>
          {openSection === 'profiles' ? <ChevronDown size={20} /> : <ChevronRight size={20} />}
        </button>
        
        {openSection === 'profiles' && (
          <div className="p-4">
            <div className="space-y-3">
              {profiles.map(profile => (
                <div key={profile.id} className="flex items-center justify-between p-3 bg-gray-50 rounded border border-gray-100">
                  <div>
                    <p className="font-medium text-gray-800">{profile.name}</p>
                    <p className="text-sm text-gray-500">{profile.standardStart} - {profile.standardEnd}</p>
                  </div>
                  <div className="flex items-center gap-2">
                    <button 
                      onClick={() => { setEditingProfileId(profile.id); setIsProfileModalOpen(true); }}
                      className="p-2 text-blue-600 hover:bg-blue-50 rounded"
                    >
                      <Edit size={16} />
                    </button>
                    <button 
                      onClick={() => confirm('Tem certeza que deseja excluir?') && deleteProfile(profile.id)}
                      className="p-2 text-red-600 hover:bg-red-50 rounded"
                    >
                      <Trash2 size={16} />
                    </button>
                  </div>
                </div>
              ))}
            </div>
            <button 
              onClick={() => { setEditingProfileId(null); setIsProfileModalOpen(true); }}
              className="mt-4 flex items-center gap-2 text-blue-600 hover:text-blue-700 font-medium"
            >
              <Plus size={16} />
              Criar novo perfil
            </button>
          </div>
        )}
      </div>

      {/* Tags Section */}
      <div className="bg-white rounded-lg shadow-sm mb-4 border border-gray-100 overflow-hidden">
        <button 
          className="w-full flex items-center justify-between p-4 bg-gray-50 hover:bg-gray-100 transition-colors"
          onClick={() => setOpenSection(openSection === 'tags' ? null : 'tags')}
        >
          <div className="flex items-center gap-2">
            <TagIcon size={20} className="text-blue-600" />
            <h2 className="text-lg font-semibold text-gray-700">Tags</h2>
          </div>
          {openSection === 'tags' ? <ChevronDown size={20} /> : <ChevronRight size={20} />}
        </button>
        
        {openSection === 'tags' && (
          <div className="p-4">
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              {tags.map(tag => (
                <div key={tag.id} className="flex items-center justify-between p-3 bg-gray-50 rounded border border-gray-100">
                  <div className="flex items-center gap-3">
                    <div className="w-4 h-4 rounded-full" style={{ backgroundColor: tag.color }} />
                    <span className="font-medium text-gray-800">{tag.name}</span>
                  </div>
                  <div className="flex items-center gap-1">
                    <button 
                      onClick={() => { setEditingTagId(tag.id); setIsTagModalOpen(true); }}
                      className="p-1.5 text-blue-600 hover:bg-blue-50 rounded"
                    >
                      <Edit size={16} />
                    </button>
                    <button 
                      onClick={() => confirm('Tem certeza que deseja excluir?') && deleteTag(tag.id)}
                      className="p-1.5 text-red-600 hover:bg-red-50 rounded"
                    >
                      <Trash2 size={16} />
                    </button>
                  </div>
                </div>
              ))}
            </div>
            <button 
              onClick={() => { setEditingTagId(null); setIsTagModalOpen(true); }}
              className="mt-4 flex items-center gap-2 text-blue-600 hover:text-blue-700 font-medium"
            >
              <Plus size={16} />
              Criar nova tag
            </button>
          </div>
        )}
      </div>

      {/* Data Section */}
      <div className="bg-white rounded-lg shadow-sm border border-gray-100 overflow-hidden">
        <button 
          className="w-full flex items-center justify-between p-4 bg-gray-50 hover:bg-gray-100 transition-colors"
          onClick={() => setOpenSection(openSection === 'data' ? null : 'data')}
        >
          <div className="flex items-center gap-2">
            <Database size={20} className="text-blue-600" />
            <h2 className="text-lg font-semibold text-gray-700">Dados</h2>
          </div>
          {openSection === 'data' ? <ChevronDown size={20} /> : <ChevronRight size={20} />}
        </button>
        
        {openSection === 'data' && (
          <div className="p-4 flex gap-4">
            <button 
              onClick={handleExport}
              className="flex-1 bg-blue-50 text-blue-700 font-medium py-2 px-4 rounded hover:bg-blue-100 transition-colors"
            >
              Exportar backup
            </button>
            <button 
              onClick={handleImport}
              className="flex-1 bg-gray-100 text-gray-700 font-medium py-2 px-4 rounded hover:bg-gray-200 transition-colors"
            >
              Importar backup
            </button>
          </div>
        )}
      </div>

      {isTagModalOpen && (
        <TagModal 
          tagId={editingTagId} 
          onClose={() => { setIsTagModalOpen(false); setEditingTagId(null); }} 
        />
      )}
      
      {isProfileModalOpen && (
        <ProfileModal 
          profileId={editingProfileId} 
          onClose={() => { setIsProfileModalOpen(false); setEditingProfileId(null); }} 
        />
      )}
    </div>
  );
}
