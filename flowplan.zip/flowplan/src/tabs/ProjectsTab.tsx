import { useState } from 'react';
import { useStore } from '../store/useStore';
import { Folder, Plus, Calendar, Tag as TagIcon, Settings2, ChevronRight, CheckCircle } from 'lucide-react';
import ProjectModal from '../components/ProjectModal';
import { format, parseISO } from 'date-fns';

export default function ProjectsTab() {
  const { projects, tags, profiles, tasks } = useStore();
  const [editingProjectId, setEditingProjectId] = useState<string | null>(null);
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [selectedProjectId, setSelectedProjectId] = useState<string | null>(null);

  const handleCreate = () => {
    setEditingProjectId(null);
    setIsModalOpen(true);
  };

  const handleEdit = (e: React.MouseEvent, id: string) => {
    e.stopPropagation();
    setEditingProjectId(id);
    setIsModalOpen(true);
  };

  if (selectedProjectId) {
    const project = projects.find(p => p.id === selectedProjectId);
    if (!project) {
      setSelectedProjectId(null);
      return null;
    }
    
    const projectTasks = tasks.filter(t => t.projectId === selectedProjectId);
    const completedTasks = projectTasks.filter(t => t.status === 'completed').length;
    const progress = projectTasks.length > 0 ? Math.round((completedTasks / projectTasks.length) * 100) : 0;

    return (
      <div className="flex flex-col h-full bg-gray-50">
        <div className="sticky top-0 bg-white z-10 px-4 py-3 border-b border-gray-200 shadow-sm flex items-center gap-3">
          <button 
            onClick={() => setSelectedProjectId(null)}
            className="p-2 -ml-2 text-gray-600 hover:bg-gray-100 rounded-full"
          >
            <ChevronRight size={24} className="rotate-180" />
          </button>
          <div className="flex-1 min-w-0">
            <h1 className="text-xl font-bold text-gray-800 truncate">{project.name}</h1>
          </div>
          <button 
            onClick={(e) => handleEdit(e, project.id)}
            className="p-2 text-blue-600 hover:bg-blue-50 rounded-full"
          >
            <Settings2 size={20} />
          </button>
        </div>
        
        <div className="p-4 overflow-y-auto flex-1 pb-24">
          <div className="bg-white rounded-xl p-4 shadow-sm border border-gray-100 mb-6">
            {project.description && (
              <p className="text-sm text-gray-600 mb-4">{project.description}</p>
            )}
            
            <div className="flex flex-wrap gap-3 mb-4">
              {project.deadline && (
                <span className="flex items-center gap-1 text-xs font-medium text-orange-600 bg-orange-50 px-2 py-1 rounded">
                  <Calendar size={14} /> {format(parseISO(project.deadline), 'dd/MM/yyyy')}
                </span>
              )}
              {project.tagId && tags.find(t => t.id === project.tagId) && (
                <span className="flex items-center gap-1 text-xs font-medium px-2 py-1 rounded" style={{ color: tags.find(t => t.id === project.tagId)!.color, backgroundColor: `${tags.find(t => t.id === project.tagId)!.color}15` }}>
                  <TagIcon size={14} /> {tags.find(t => t.id === project.tagId)!.name}
                </span>
              )}
              {project.profileId && profiles.find(p => p.id === project.profileId) && (
                <span className="flex items-center gap-1 text-xs font-medium text-blue-600 bg-blue-50 px-2 py-1 rounded">
                  <Settings2 size={14} /> {profiles.find(p => p.id === project.profileId)!.name}
                </span>
              )}
            </div>

            <div>
              <div className="flex justify-between text-xs mb-1">
                <span className="font-medium text-gray-600">Progresso</span>
                <span className="font-bold text-gray-800">{progress}%</span>
              </div>
              <div className="h-2 bg-gray-100 rounded-full overflow-hidden">
                <div className="h-full bg-blue-500 rounded-full" style={{ width: `${progress}%` }} />
              </div>
              <p className="text-xs text-gray-500 mt-1">{completedTasks} de {projectTasks.length} tarefas concluídas</p>
            </div>
          </div>

          <div className="flex items-center justify-between mb-4">
            <h2 className="text-lg font-bold text-gray-800">Tarefas do Projeto</h2>
          </div>

          {projectTasks.length === 0 ? (
            <div className="text-center py-8 text-gray-500 text-sm italic">
              Nenhuma tarefa neste projeto. Adicione tarefas através da aba Tarefas.
            </div>
          ) : (
            <div className="space-y-2">
              {projectTasks.map(task => (
                <div key={task.id} className="bg-white p-3 rounded-lg border border-gray-100 shadow-sm flex items-center gap-3">
                  <div className={`w-4 h-4 rounded-full border flex items-center justify-center shrink-0 ${task.status === 'completed' ? 'bg-green-500 border-green-500 text-white' : 'border-gray-300'}`}>
                    {task.status === 'completed' && <CheckCircle size={12} className="stroke-[3]" />}
                  </div>
                  <span className={`text-sm flex-1 truncate ${task.status === 'completed' ? 'line-through text-gray-400' : 'font-medium text-gray-800'}`}>
                    {task.name}
                  </span>
                  <span className="text-xs text-gray-500">{task.duration} min</span>
                </div>
              ))}
            </div>
          )}
        </div>
        
        {isModalOpen && (
          <ProjectModal projectId={editingProjectId} onClose={() => setIsModalOpen(false)} />
        )}
      </div>
    );
  }

  return (
    <div className="flex flex-col h-full bg-gray-50">
      <div className="sticky top-0 bg-white z-10 px-4 py-3 border-b border-gray-200 shadow-sm flex justify-between items-center">
        <h1 className="text-xl font-bold text-gray-800">Projetos</h1>
        <button 
          onClick={handleCreate}
          className="p-2 bg-blue-50 text-blue-600 rounded-lg hover:bg-blue-100 transition-colors flex items-center gap-1 text-sm font-medium"
        >
          <Plus size={16} /> Novo
        </button>
      </div>

      <div className="p-4 overflow-y-auto flex-1 pb-24 space-y-3">
        {projects.length === 0 && (
          <div className="flex flex-col items-center justify-center py-12 px-4 text-center">
            <div className="w-16 h-16 bg-gray-100 rounded-full flex items-center justify-center text-gray-400 mb-4">
              <Folder size={32} />
            </div>
            <h3 className="text-lg font-medium text-gray-800 mb-1">Nenhum projeto</h3>
            <p className="text-sm text-gray-500">Crie projetos para agrupar suas tarefas.</p>
          </div>
        )}

        {projects.map(project => {
          const projectTasks = tasks.filter(t => t.projectId === project.id);
          const completedTasks = projectTasks.filter(t => t.status === 'completed').length;
          const progress = projectTasks.length > 0 ? Math.round((completedTasks / projectTasks.length) * 100) : 0;
          const tag = tags.find(t => t.id === project.tagId);

          return (
            <div 
              key={project.id} 
              onClick={() => setSelectedProjectId(project.id)}
              className="bg-white rounded-xl p-4 shadow-sm border border-gray-100 cursor-pointer hover:border-blue-300 transition-colors group"
            >
              <div className="flex justify-between items-start mb-2">
                <div className="flex items-center gap-2">
                  <div className="w-3 h-3 rounded-full shrink-0" style={{ backgroundColor: tag?.color || '#cbd5e1' }} />
                  <h2 className="font-bold text-gray-800 truncate">{project.name}</h2>
                </div>
                <button 
                  onClick={(e) => handleEdit(e, project.id)}
                  className="p-1.5 text-gray-400 hover:text-blue-600 hover:bg-blue-50 rounded opacity-0 group-hover:opacity-100 transition-opacity"
                >
                  <Settings2 size={16} />
                </button>
              </div>

              {project.description && (
                <p className="text-xs text-gray-500 mb-3 line-clamp-2">{project.description}</p>
              )}

              <div className="flex items-center gap-4 text-xs font-medium mb-3">
                <span className="text-gray-600">{projectTasks.length} tarefas</span>
                {project.deadline && (
                  <span className="text-orange-600 flex items-center gap-1">
                    <Calendar size={12} /> {format(parseISO(project.deadline), 'dd/MM/yyyy')}
                  </span>
                )}
              </div>

              <div>
                <div className="h-1.5 bg-gray-100 rounded-full overflow-hidden">
                  <div className="h-full bg-blue-500 rounded-full" style={{ width: `${progress}%` }} />
                </div>
              </div>
            </div>
          );
        })}
      </div>

      {isModalOpen && (
        <ProjectModal projectId={editingProjectId} onClose={() => setIsModalOpen(false)} />
      )}
    </div>
  );
}
