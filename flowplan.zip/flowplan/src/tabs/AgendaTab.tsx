import { useState, useMemo } from 'react';
import { useStore } from '../store/useStore';
import { format, addDays, subDays, addWeeks, subWeeks, addMonths, subMonths, startOfWeek } from 'date-fns';
import { ptBR } from 'date-fns/locale';
import { ChevronLeft, ChevronRight, Filter, Zap } from 'lucide-react';
import AgendaGrid from '../components/AgendaGrid';
import MonthlyView from '../components/MonthlyView';
import TaskModal from '../components/TaskModal';

type ViewMode = 'daily' | 'weekly' | 'monthly';

export default function AgendaTab() {
  const { tasks, slots, tags, projects, profiles, autoSchedule } = useStore();
  const [viewMode, setViewMode] = useState<ViewMode>('daily');
  const [currentDate, setCurrentDate] = useState(new Date());
  
  const [editingTaskId, setEditingTaskId] = useState<string | null>(null);
  const [isScheduling, setIsScheduling] = useState(false);

  // Filter state
  const [showFilters, setShowFilters] = useState(false);
  const [filterTag, setFilterTag] = useState<string>('all');
  const [filterProject, setFilterProject] = useState<string>('all');
  const [filterProfile, setFilterProfile] = useState<string>('all');

  const handleNext = () => {
    if (viewMode === 'daily') setCurrentDate(addDays(currentDate, 1));
    else if (viewMode === 'weekly') setCurrentDate(addWeeks(currentDate, 1));
    else setCurrentDate(addMonths(currentDate, 1));
  };

  const handlePrev = () => {
    if (viewMode === 'daily') setCurrentDate(subDays(currentDate, 1));
    else if (viewMode === 'weekly') setCurrentDate(subWeeks(currentDate, 1));
    else setCurrentDate(subMonths(currentDate, 1));
  };

  const handleToday = () => {
    setCurrentDate(new Date());
  };

  const clearFilters = () => {
    setFilterTag('all');
    setFilterProject('all');
    setFilterProfile('all');
  };

  const handleAutoSchedule = async () => {
    setIsScheduling(true);
    try {
      autoSchedule();
    } finally {
      setIsScheduling(false);
    }
  };

  const filteredTasks = useMemo(() => {
    return tasks.filter(task => {
      if (filterTag !== 'all' && task.tagId !== filterTag) return false;
      if (filterProject !== 'all' && (task.projectId || 'no-project') !== filterProject) return false;
      if (filterProfile !== 'all' && (task.profileId || 'no-profile') !== filterProfile) return false;
      return true;
    });
  }, [tasks, filterTag, filterProject, filterProfile]);

  const filteredSlots = useMemo(() => {
    return slots.filter(slot => {
      const task = tasks.find(t => t.id === slot.taskId);
      if (!task) return false;
      if (filterTag !== 'all' && task.tagId !== filterTag) return false;
      if (filterProject !== 'all' && (task.projectId || 'no-project') !== filterProject) return false;
      if (filterProfile !== 'all' && (task.profileId || 'no-profile') !== filterProfile) return false;
      return true;
    });
  }, [slots, tasks, filterTag, filterProject, filterProfile]);

  return (
    <div className="flex flex-col h-full bg-white relative">
      {/* Header */}
      <div className="sticky top-0 bg-white z-20 px-4 py-3 border-b border-gray-200 shadow-sm">
        <div className="flex justify-between items-center mb-3">
          <div className="flex items-center gap-2">
            <button onClick={handleToday} className="px-3 py-1.5 border border-gray-300 rounded-lg text-sm font-medium text-gray-700 hover:bg-gray-50">
              Hoje
            </button>
            <div className="flex items-center">
              <button onClick={handlePrev} className="p-1.5 text-gray-600 hover:bg-gray-100 rounded-full"><ChevronLeft size={20} /></button>
              <button onClick={handleNext} className="p-1.5 text-gray-600 hover:bg-gray-100 rounded-full"><ChevronRight size={20} /></button>
            </div>
            <h2 className="text-lg font-bold text-gray-800 capitalize ml-1">
              {viewMode === 'daily' && format(currentDate, "dd 'de' MMMM", { locale: ptBR })}
              {viewMode === 'weekly' && format(currentDate, "MMMM yyyy", { locale: ptBR })}
              {viewMode === 'monthly' && format(currentDate, "MMMM yyyy", { locale: ptBR })}
            </h2>
          </div>
          
          <div className="flex items-center gap-2">
            <button 
              onClick={() => setShowFilters(!showFilters)}
              className={`p-2 rounded-lg ${showFilters || filterTag !== 'all' || filterProject !== 'all' || filterProfile !== 'all' ? 'bg-blue-100 text-blue-700' : 'bg-gray-100 text-gray-600 hover:bg-gray-200'}`}
            >
              <Filter size={18} />
            </button>
            <div className="bg-gray-100 p-1 rounded-lg flex text-sm font-medium">
              <button onClick={() => setViewMode('daily')} className={`px-2 py-1 rounded ${viewMode === 'daily' ? 'bg-white shadow-sm text-gray-800' : 'text-gray-500'}`}>D</button>
              <button onClick={() => setViewMode('weekly')} className={`px-2 py-1 rounded ${viewMode === 'weekly' ? 'bg-white shadow-sm text-gray-800' : 'text-gray-500'}`}>S</button>
              <button onClick={() => setViewMode('monthly')} className={`px-2 py-1 rounded ${viewMode === 'monthly' ? 'bg-white shadow-sm text-gray-800' : 'text-gray-500'}`}>M</button>
            </div>
          </div>
        </div>

        {showFilters && (
          <div className="bg-gray-50 border border-gray-200 rounded-lg p-3 text-sm animate-in fade-in slide-in-from-top-2">
            <div className="grid grid-cols-3 gap-2 mb-2">
              <select value={filterTag} onChange={e => setFilterTag(e.target.value)} className="bg-white border border-gray-200 rounded px-2 py-1.5 outline-none">
                <option value="all">Todas as Tags</option>
                {tags.map(t => <option key={t.id} value={t.id}>{t.name}</option>)}
              </select>
              <select value={filterProject} onChange={e => setFilterProject(e.target.value)} className="bg-white border border-gray-200 rounded px-2 py-1.5 outline-none">
                <option value="all">Todos os Projetos</option>
                <option value="no-project">Sem Projeto</option>
                {projects.map(p => <option key={p.id} value={p.id}>{p.name}</option>)}
              </select>
              <select value={filterProfile} onChange={e => setFilterProfile(e.target.value)} className="bg-white border border-gray-200 rounded px-2 py-1.5 outline-none">
                <option value="all">Todos os Perfis</option>
                <option value="no-profile">Sem Perfil</option>
                {profiles.map(p => <option key={p.id} value={p.id}>{p.name}</option>)}
              </select>
            </div>
            <button onClick={clearFilters} className="text-xs text-blue-600 hover:underline">Limpar filtros</button>
          </div>
        )}
      </div>

      <div className="flex-1 overflow-hidden relative bg-white pb-16">
        {viewMode === 'daily' && (
          <AgendaGrid 
            date={currentDate} 
            daysCount={1} 
            tasks={filteredTasks} 
            slots={filteredSlots}
            onTaskClick={setEditingTaskId}
            onTaskDelete={() => {}}
            onNavigate={(dir) => dir === 'next' ? handleNext() : handlePrev()}
          />
        )}
        {viewMode === 'weekly' && (
          <AgendaGrid 
            date={startOfWeek(currentDate)} 
            daysCount={7} 
            tasks={filteredTasks} 
            slots={filteredSlots}
            onTaskClick={setEditingTaskId}
            onTaskDelete={() => {}}
            onNavigate={(dir) => dir === 'next' ? handleNext() : handlePrev()}
          />
        )}
        {viewMode === 'monthly' && (
          <MonthlyView 
            date={currentDate} 
            tasks={filteredTasks}
            slots={filteredSlots}
            onDayClick={(d) => { setCurrentDate(d); setViewMode('daily'); }}
          />
        )}
      </div>
      
      {editingTaskId && (
        <TaskModal taskId={editingTaskId} onClose={() => setEditingTaskId(null)} />
      )}
      
      <div className="absolute bottom-[4.5rem] right-4 z-30">
        <button 
          disabled={isScheduling}
          className="bg-gradient-to-r from-purple-600 to-indigo-600 text-white px-4 py-3 rounded-full shadow-lg font-bold flex items-center gap-2 hover:from-purple-700 hover:to-indigo-700 transition-all disabled:opacity-50"
          onClick={handleAutoSchedule}
        >
          <Zap size={18} /> {isScheduling ? 'Reagendando...' : 'Reagendar'}
        </button>
      </div>
    </div>
  );
}
