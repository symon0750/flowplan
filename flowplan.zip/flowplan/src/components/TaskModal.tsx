import { useState, useEffect } from 'react';
import { useStore } from '../store/useStore';
import { X, Calendar, Clock, Tag as TagIcon, Folder, AlertCircle, Plus, Trash2, Check } from 'lucide-react';
import { Task, Priority, RepeatType, Subtask } from '../store/types';
import { v4 as uuidv4 } from 'uuid';

interface TaskModalProps {
  taskId?: string | null;
  onClose: () => void;
}

export default function TaskModal({ taskId, onClose }: TaskModalProps) {
  const { tasks, projects, tags, profiles, addTask, updateTask, deleteTask } = useStore();
  
  const [name, setName] = useState('');
  const [description, setDescription] = useState('');
  const [durationHours, setDurationHours] = useState(0);
  const [durationMinutes, setDurationMinutes] = useState(30);
  const [priority, setPriority] = useState<Priority>('medium');
  const [tagId, setTagId] = useState('');
  const [projectId, setProjectId] = useState('');
  const [profileId, setProfileId] = useState('');
  
  const [deadline, setDeadline] = useState('');
  const [deadlineTime, setDeadlineTime] = useState('');
  const [availableFrom, setAvailableFrom] = useState('');
  const [timeRestrictionStart, setTimeRestrictionStart] = useState('');
  const [timeRestrictionEnd, setTimeRestrictionEnd] = useState('');
  const [buffer, setBuffer] = useState(0);
  
  const [isFixed, setIsFixed] = useState(false);
  const [fixedStart, setFixedStart] = useState('');
  const [fixedEnd, setFixedEnd] = useState('');
  
  const [repeat, setRepeat] = useState<RepeatType>('none');
  const [repeatInterval, setRepeatInterval] = useState(1);
  const [repeatDays, setRepeatDays] = useState<number[]>([]);
  
  const [divisible, setDivisible] = useState(false);
  const [minSession, setMinSession] = useState(15);
  
  const [subtasks, setSubtasks] = useState<Subtask[]>([]);
  const [newSubtask, setNewSubtask] = useState('');
  
  const [error, setError] = useState<string | null>(null);
  const [showDeleteConfirm, setShowDeleteConfirm] = useState(false);

  useEffect(() => {
    if (taskId) {
      const task = tasks.find(t => t.id === taskId);
      if (task) {
        setName(task.name);
        setDescription(task.description || '');
        const totalMinutes = task.duration;
        setDurationHours(Math.floor(totalMinutes / 60));
        setDurationMinutes(totalMinutes % 60);
        setPriority(task.priority);
        setTagId(task.tagId || '');
        setProjectId(task.projectId || '');
        setProfileId(task.profileId || '');
        setDeadline(task.deadline ? task.deadline.substring(0, 10) : '');
        setDeadlineTime(task.deadlineTime || '');
        setAvailableFrom(task.availableFrom ? task.availableFrom.substring(0, 10) : '');
        setTimeRestrictionStart(task.timeRestrictionStart || '');
        setTimeRestrictionEnd(task.timeRestrictionEnd || '');
        setBuffer(task.buffer);
        setIsFixed(task.isFixed);
        setFixedStart(task.fixedStart ? task.fixedStart.substring(0, 16) : '');
        setFixedEnd(task.fixedEnd ? task.fixedEnd.substring(0, 16) : '');
        setRepeat(task.repeat);
        setRepeatInterval(task.repeatInterval || 1);
        setRepeatDays(task.repeatDays || []);
        setDivisible(task.divisible);
        setMinSession(task.minSession || 15);
        setSubtasks(task.subtasks || []);
      }
    }
  }, [taskId, tasks]);

  const getTotalDuration = () => durationHours * 60 + durationMinutes;

  const validate = (): string | null => {
    // Validação 1: Nome obrigatório
    if (!name.trim()) {
      return "Preencha o nome da tarefa";
    }

    // Validação 2: Duração válida
    const totalDuration = getTotalDuration();
    if (totalDuration <= 0) {
      return "Informe uma duração válida (mínimo 1 minuto)";
    }

    // Validação 3: Tarefa fixa
    if (isFixed) {
      if (!fixedStart || !fixedEnd) {
        return "Informe data e hora de início e fim para evento fixo";
      }
      if (fixedStart >= fixedEnd) {
        return "A hora de início deve ser anterior à hora de fim";
      }
      if (divisible) {
        return "Um evento fixo não pode ser dividido em sessões";
      }
    }

    // Validação 4: Recorrência e divisibilidade não podem coexistir
    if (repeat !== 'none' && divisible) {
      return "Uma tarefa recorrente não pode ser dividida em sessões";
    }

    // Validação 5: Recorrência diária requer intervalo válido
    if (repeat === 'daily' && repeatInterval < 1) {
      return "Intervalo de recorrência deve ser >= 1 dia";
    }

    // Validação 6: Recorrência semanal requer intervalo e dias
    if (repeat === 'weekly') {
      if (repeatInterval < 1) {
        return "Intervalo de recorrência deve ser >= 1 semana";
      }
      if (repeatDays.length === 0) {
        return "Selecione pelo menos um dia da semana";
      }
    }

    // Validação 7: Divisibilidade com sessão mínima válida
    if (divisible) {
      if (minSession < 1) {
        return "Sessão mínima deve ser >= 1 minuto";
      }
      if (minSession > totalDuration) {
        return "Sessão mínima não pode ser maior que a duração total";
      }
    }

    // Validação 8: Prazo com horário máximo
    if (deadline && deadlineTime) {
      // Apenas validação de formato
      if (!/^\d{2}:\d{2}$/.test(deadlineTime)) {
        return "Informe o horário máximo no formato HH:MM";
      }
    }

    return null;
  };

  const addSubtask = () => {
    if (!newSubtask.trim()) return;
    const subtask: Subtask = {
      id: uuidv4(),
      title: newSubtask.trim(),
      completed: false
    };
    setSubtasks([...subtasks, subtask]);
    setNewSubtask('');
  };

  const toggleSubtask = (id: string) => {
    setSubtasks(subtasks.map(s => 
      s.id === id ? { ...s, completed: !s.completed } : s
    ));
  };

  const removeSubtask = (id: string) => {
    setSubtasks(subtasks.filter(s => s.id !== id));
  };

  const toggleRepeatDay = (day: number) => {
    if (repeatDays.includes(day)) {
      setRepeatDays(repeatDays.filter(d => d !== day));
    } else {
      setRepeatDays([...repeatDays, day].sort());
    }
  };

  const handleSave = () => {
    const validationError = validate();
    if (validationError) {
      setError(validationError);
      return;
    }

    const totalDuration = getTotalDuration();

    const data: Omit<Task, 'id'> = {
      name: name.trim(),
      description: description.trim() || undefined,
      duration: totalDuration,
      priority,
      tagId: tagId || undefined,
      projectId: projectId || undefined,
      profileId: profileId || undefined,
      deadline: deadline ? new Date(deadline).toISOString() : undefined,
      deadlineTime: deadline && deadlineTime ? deadlineTime : undefined,
      availableFrom: availableFrom ? new Date(availableFrom).toISOString() : undefined,
      timeRestrictionStart: timeRestrictionStart || undefined,
      timeRestrictionEnd: timeRestrictionEnd || undefined,
      buffer,
      isFixed,
      fixedStart: fixedStart ? new Date(fixedStart).toISOString() : undefined,
      fixedEnd: fixedEnd ? new Date(fixedEnd).toISOString() : undefined,
      repeat,
      repeatInterval: repeat !== 'none' ? repeatInterval : undefined,
      repeatDays: repeat === 'weekly' ? repeatDays : undefined,
      divisible,
      minSession: divisible ? minSession : undefined,
      dependencies: [],
      subtasks: subtasks.length > 0 ? subtasks : [],
      status: 'pending',
      isPinned: isFixed,
      isPlanned: false
    };

    try {
      if (taskId) {
        updateTask(taskId, data);
      } else {
        addTask(data);
      }
      onClose();
    } catch (err) {
      setError('Erro ao salvar tarefa. Tente novamente.');
    }
  };

  const handleDelete = () => {
    if (taskId) {
      try {
        deleteTask(taskId);
        onClose();
      } catch (err) {
        setError('Erro ao deletar tarefa. Tente novamente.');
      }
    }
  };

  return (
    <div className="fixed inset-0 bg-black/50 z-[100] flex justify-center items-end sm:items-center">
      <div className="bg-white w-full max-w-3xl rounded-t-2xl sm:rounded-2xl shadow-2xl flex flex-col max-h-[95vh]">
        {/* Header */}
        <div className="flex justify-between items-center p-6 border-b border-gray-200 shrink-0">
          <h2 className="text-2xl font-bold text-gray-800">
            {taskId ? 'Editar Tarefa' : 'Nova Tarefa'}
          </h2>
          <button 
            onClick={onClose} 
            className="p-2 hover:bg-gray-100 rounded-full text-gray-500 transition-colors"
          >
            <X size={24} />
          </button>
        </div>

        {/* Content */}
        <div className="overflow-y-auto flex-1 p-6 space-y-6">
          {/* Error Alert */}
          {error && (
            <div className="flex items-start gap-3 p-4 bg-red-50 text-red-700 rounded-lg border border-red-200 animate-in fade-in">
              <AlertCircle size={20} className="shrink-0 mt-0.5" />
              <div>
                <p className="font-medium">{error}</p>
              </div>
            </div>
          )}

          {/* Section 1: Basic Info */}
          <div className="space-y-4">
            <h3 className="text-sm font-semibold text-gray-900 uppercase tracking-wide">Informações Básicas</h3>
            
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                Nome da Tarefa <span className="text-red-500">*</span>
              </label>
              <input 
                type="text" 
                value={name}
                onChange={(e) => { setName(e.target.value); setError(null); }}
                className="w-full border border-gray-300 rounded-lg px-4 py-2.5 text-base outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent transition"
                placeholder="O que precisa ser feito?"
                autoFocus
              />
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">Descrição</label>
              <textarea 
                value={description}
                onChange={(e) => setDescription(e.target.value)}
                className="w-full border border-gray-300 rounded-lg px-4 py-2.5 text-base outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent transition resize-none"
                placeholder="Descreva os detalhes da tarefa..."
                rows={3}
              />
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
              {/* Duration - Hours and Minutes */}
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  Duração - Horas <span className="text-red-500">*</span>
                </label>
                <input 
                  type="number" 
                  value={durationHours}
                  onChange={(e) => { setDurationHours(Math.max(0, parseInt(e.target.value) || 0)); setError(null); }}
                  className="w-full border border-gray-300 rounded-lg px-3 py-2 outline-none focus:ring-2 focus:ring-blue-500 text-base"
                  min="0"
                />
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  Duração - Minutos <span className="text-red-500">*</span>
                </label>
                <input 
                  type="number" 
                  value={durationMinutes}
                  onChange={(e) => { setDurationMinutes(Math.max(0, Math.min(59, parseInt(e.target.value) || 0))); setError(null); }}
                  className="w-full border border-gray-300 rounded-lg px-3 py-2 outline-none focus:ring-2 focus:ring-blue-500 text-base"
                  min="0"
                  max="59"
                />
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">Prioridade</label>
                <select 
                  value={priority}
                  onChange={(e) => setPriority(e.target.value as Priority)}
                  className="w-full border border-gray-300 rounded-lg px-3 py-2 outline-none focus:ring-2 focus:ring-blue-500 text-base"
                >
                  <option value="low">Baixa</option>
                  <option value="medium">Média</option>
                  <option value="high">Alta</option>
                  <option value="urgent">Urgente</option>
                </select>
              </div>
            </div>
          </div>

          <hr className="border-gray-200" />

          {/* Section 2: Categorization */}
          <div className="space-y-4">
            <h3 className="text-sm font-semibold text-gray-900 uppercase tracking-wide">Categorização</h3>
            
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">Projeto</label>
                <select 
                  value={projectId}
                  onChange={(e) => setProjectId(e.target.value)}
                  className="w-full border border-gray-300 rounded-lg px-3 py-2 outline-none focus:ring-2 focus:ring-blue-500 text-base"
                >
                  <option value="">Sem projeto</option>
                  {projects.map(p => <option key={p.id} value={p.id}>{p.name}</option>)}
                </select>
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">Tag</label>
                <select 
                  value={tagId}
                  onChange={(e) => setTagId(e.target.value)}
                  className="w-full border border-gray-300 rounded-lg px-3 py-2 outline-none focus:ring-2 focus:ring-blue-500 text-base"
                >
                  <option value="">Sem tag</option>
                  {tags.map(t => (
                    <option key={t.id} value={t.id} style={{ paddingLeft: '10px' }}>
                      ● {t.name}
                    </option>
                  ))}
                </select>
              </div>
            </div>
          </div>

          <hr className="border-gray-200" />

          {/* Section 3: Scheduling */}
          <div className="space-y-4">
            <h3 className="text-sm font-semibold text-gray-900 uppercase tracking-wide">Agendamento e Prazos</h3>
            
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">Prazo (Data)</label>
                <input 
                  type="date" 
                  value={deadline}
                  onChange={(e) => setDeadline(e.target.value)}
                  className="w-full border border-gray-300 rounded-lg px-3 py-2 outline-none focus:ring-2 focus:ring-blue-500 text-base"
                />
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">Horário Máximo (HH:MM)</label>
                <input 
                  type="time" 
                  value={deadlineTime}
                  onChange={(e) => setDeadlineTime(e.target.value)}
                  disabled={!deadline}
                  className="w-full border border-gray-300 rounded-lg px-3 py-2 outline-none focus:ring-2 focus:ring-blue-500 text-base disabled:bg-gray-100 disabled:text-gray-500"
                />
              </div>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">Disponível a partir de</label>
                <input 
                  type="date" 
                  value={availableFrom}
                  onChange={(e) => setAvailableFrom(e.target.value)}
                  className="w-full border border-gray-300 rounded-lg px-3 py-2 outline-none focus:ring-2 focus:ring-blue-500 text-base"
                />
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">Perfil de Horário</label>
                <select 
                  value={profileId}
                  onChange={(e) => setProfileId(e.target.value)}
                  disabled={isFixed}
                  className="w-full border border-gray-300 rounded-lg px-3 py-2 outline-none focus:ring-2 focus:ring-blue-500 text-base disabled:bg-gray-100 disabled:text-gray-500"
                >
                  <option value="">Qualquer horário</option>
                  {profiles.map(p => <option key={p.id} value={p.id}>{p.name}</option>)}
                </select>
              </div>
            </div>
          </div>

          <hr className="border-gray-200" />

          {/* Section 4: Recurrence & Scheduling Rules */}
          <div className="space-y-4">
            <h3 className="text-sm font-semibold text-gray-900 uppercase tracking-wide">Regras de Agendamento</h3>
            
            {/* Fixed Event Checkbox */}
            <label className="flex items-center gap-3 cursor-pointer p-3 bg-blue-50 rounded-lg border border-blue-200 hover:bg-blue-100 transition">
              <input 
                type="checkbox" 
                checked={isFixed}
                onChange={(e) => { setIsFixed(e.target.checked); setError(null); }}
                className="w-5 h-5 text-blue-600 rounded accent-blue-600"
              />
              <span className="font-medium text-gray-800">Fixar no calendário (evento com horário fixo)</span>
            </label>
            
            {isFixed ? (
              // Fixed Event Fields
              <div className="p-4 bg-amber-50 border border-amber-200 rounded-lg space-y-4">
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-2">Início <span className="text-red-500">*</span></label>
                    <input 
                      type="datetime-local" 
                      value={fixedStart}
                      onChange={(e) => { setFixedStart(e.target.value); setError(null); }}
                      className="w-full border border-gray-300 rounded-lg px-3 py-2 outline-none focus:ring-2 focus:ring-blue-500 text-base"
                    />
                  </div>
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-2">Fim <span className="text-red-500">*</span></label>
                    <input 
                      type="datetime-local" 
                      value={fixedEnd}
                      onChange={(e) => { setFixedEnd(e.target.value); setError(null); }}
                      className="w-full border border-gray-300 rounded-lg px-3 py-2 outline-none focus:ring-2 focus:ring-blue-500 text-base"
                    />
                  </div>
                </div>
                <p className="text-sm text-amber-700">⚠️ Eventos fixos não podem ser divididos em sessões ou recorrentes.</p>
              </div>
            ) : (
              // Schedulable Task Fields
              <div className="space-y-5">
                {/* Recurrence */}
                <div className="border border-gray-200 rounded-lg p-4 space-y-3">
                  <label className="block text-sm font-semibold text-gray-800">Recorrência</label>
                  <select 
                    value={repeat}
                    onChange={(e) => {
                      const newRepeat = e.target.value as RepeatType;
                      setRepeat(newRepeat);
                      if (newRepeat === 'none') {
                        setRepeatInterval(1);
                        setRepeatDays([]);
                      }
                      setError(null);
                    }}
                    className="w-full border border-gray-300 rounded-lg px-3 py-2 outline-none focus:ring-2 focus:ring-blue-500 text-base"
                  >
                    <option value="none">Não repetir</option>
                    <option value="daily">Diária</option>
                    <option value="weekly">Semanal</option>
                  </select>

                  {repeat === 'daily' && (
                    <div className="flex items-end gap-3 mt-3 p-3 bg-gray-50 rounded">
                      <div className="flex-1">
                        <label className="block text-xs font-medium text-gray-600 mb-1">A cada N dias</label>
                        <input 
                          type="number" 
                          value={repeatInterval}
                          onChange={(e) => { setRepeatInterval(Math.max(1, parseInt(e.target.value) || 1)); setError(null); }}
                          className="w-full border border-gray-300 rounded px-2 py-1 outline-none text-sm"
                          min="1"
                        />
                      </div>
                    </div>
                  )}

                  {repeat === 'weekly' && (
                    <div className="space-y-3 p-3 bg-gray-50 rounded">
                      <div>
                        <label className="block text-xs font-medium text-gray-600 mb-1">A cada N semanas</label>
                        <input 
                          type="number" 
                          value={repeatInterval}
                          onChange={(e) => { setRepeatInterval(Math.max(1, parseInt(e.target.value) || 1)); setError(null); }}
                          className="w-full border border-gray-300 rounded px-2 py-1 outline-none text-sm"
                          min="1"
                        />
                      </div>
                      <div>
                        <label className="block text-xs font-medium text-gray-600 mb-2">Dias da semana</label>
                        <div className="grid grid-cols-7 gap-2">
                          {['Dom', 'Seg', 'Ter', 'Qua', 'Qui', 'Sex', 'Sáb'].map((day, index) => (
                            <button
                              key={index}
                              onClick={() => { toggleRepeatDay(index); setError(null); }}
                              className={`py-2 rounded font-medium text-sm transition ${
                                repeatDays.includes(index)
                                  ? 'bg-blue-600 text-white border border-blue-600'
                                  : 'bg-white text-gray-700 border border-gray-300 hover:border-gray-400'
                              }`}
                            >
                              {day}
                            </button>
                          ))}
                        </div>
                      </div>
                    </div>
                  )}
                </div>

                {/* Divisibility */}
                <div className="border border-gray-200 rounded-lg p-4 space-y-3">
                  <label className="flex items-center gap-3 cursor-pointer">
                    <input 
                      type="checkbox" 
                      checked={divisible}
                      onChange={(e) => {
                        setDivisible(e.target.checked);
                        if (repeat !== 'none') {
                          setError('Uma tarefa recorrente não pode ser dividida em sessões');
                        } else {
                          setError(null);
                        }
                      }}
                      disabled={repeat !== 'none'}
                      className="w-5 h-5 text-blue-600 rounded accent-blue-600 disabled:opacity-50"
                    />
                    <span className={`font-medium ${repeat !== 'none' ? 'text-gray-400' : 'text-gray-800'}`}>
                      Permitir dividir em sessões
                    </span>
                  </label>
                  
                  {divisible && (
                    <div className="p-3 bg-green-50 border border-green-200 rounded space-y-2">
                      <label className="block text-xs font-medium text-gray-600">Sessão Mínima (minutos)</label>
                      <input 
                        type="number" 
                        value={minSession}
                        onChange={(e) => { setMinSession(Math.max(1, parseInt(e.target.value) || 1)); setError(null); }}
                        className="w-full border border-gray-300 rounded px-3 py-2 outline-none text-sm"
                        min="1"
                      />
                      <p className="text-xs text-green-700">
                        📌 Fatias intermediárias terão mínimo {minSession}min. A última fatia pode ser menor.
                      </p>
                    </div>
                  )}

                  {repeat !== 'none' && (
                    <p className="text-xs text-red-600 font-medium">⚠️ Desative a recorrência para usar divisibilidade</p>
                  )}
                </div>

                {/* Buffer and Time Restrictions */}
                <div className="border border-gray-200 rounded-lg p-4 space-y-4">
                  <label className="block text-sm font-semibold text-gray-800">Restrições e Buffer</label>
                  <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
                    <div>
                      <label className="block text-xs font-medium text-gray-600 mb-1">Início Cedo (HH:MM)</label>
                      <input 
                        type="time" 
                        value={timeRestrictionStart}
                        onChange={(e) => setTimeRestrictionStart(e.target.value)}
                        className="w-full border border-gray-300 rounded-lg px-3 py-2 outline-none focus:ring-2 focus:ring-blue-500 text-sm"
                      />
                    </div>
                    <div>
                      <label className="block text-xs font-medium text-gray-600 mb-1">Fim Tarde (HH:MM)</label>
                      <input 
                        type="time" 
                        value={timeRestrictionEnd}
                        onChange={(e) => setTimeRestrictionEnd(e.target.value)}
                        className="w-full border border-gray-300 rounded-lg px-3 py-2 outline-none focus:ring-2 focus:ring-blue-500 text-sm"
                      />
                    </div>
                    <div>
                      <label className="block text-xs font-medium text-gray-600 mb-1">Buffer (minutos)</label>
                      <input 
                        type="number" 
                        value={buffer}
                        onChange={(e) => setBuffer(Math.max(0, parseInt(e.target.value) || 0))}
                        className="w-full border border-gray-300 rounded-lg px-3 py-2 outline-none focus:ring-2 focus:ring-blue-500 text-sm"
                        min="0"
                      />
                    </div>
                  </div>
                </div>
              </div>
            )}
          </div>

          <hr className="border-gray-200" />

          {/* Section 5: Subtasks */}
          <div className="space-y-4">
            <h3 className="text-sm font-semibold text-gray-900 uppercase tracking-wide">Subtarefas (Checklist)</h3>
            
            <div className="space-y-2">
              {subtasks.length > 0 && (
                <ul className="space-y-2 max-h-48 overflow-y-auto border border-gray-200 rounded-lg p-3">
                  {subtasks.map(sub => (
                    <li key={sub.id} className="flex items-center gap-3 p-2 bg-gray-50 rounded hover:bg-gray-100 transition">
                      <button
                        onClick={() => toggleSubtask(sub.id)}
                        className={`shrink-0 w-5 h-5 rounded border-2 flex items-center justify-center transition ${
                          sub.completed
                            ? 'bg-green-500 border-green-500'
                            : 'border-gray-300 hover:border-gray-400'
                        }`}
                      >
                        {sub.completed && <Check size={14} className="text-white" />}
                      </button>
                      <span className={`flex-1 text-sm ${sub.completed ? 'line-through text-gray-400' : 'text-gray-800'}`}>
                        {sub.title}
                      </span>
                      <button
                        onClick={() => removeSubtask(sub.id)}
                        className="shrink-0 p-1 text-red-500 hover:bg-red-50 rounded transition"
                      >
                        <X size={16} />
                      </button>
                    </li>
                  ))}
                </ul>
              )}

              <div className="flex gap-2">
                <input 
                  type="text" 
                  value={newSubtask}
                  onChange={(e) => setNewSubtask(e.target.value)}
                  onKeyPress={(e) => e.key === 'Enter' && addSubtask()}
                  className="flex-1 border border-gray-300 rounded-lg px-3 py-2 outline-none focus:ring-2 focus:ring-blue-500 text-sm"
                  placeholder="Adicionar nova subtarefa..."
                />
                <button
                  onClick={addSubtask}
                  className="px-4 py-2 bg-blue-600 hover:bg-blue-700 text-white rounded-lg font-medium flex items-center gap-2 transition"
                >
                  <Plus size={16} /> Adicionar
                </button>
              </div>
            </div>
          </div>
        </div>

        {/* Footer */}
        <div className="p-4 border-t border-gray-200 flex justify-between gap-3 shrink-0 bg-gray-50 rounded-b-2xl">
          {taskId ? (
            <button 
              onClick={() => setShowDeleteConfirm(true)}
              className="px-4 py-2 text-red-600 hover:bg-red-50 rounded-lg font-medium transition-colors"
            >
              Excluir
            </button>
          ) : <div></div>}
          
          <div className="flex gap-3">
            <button 
              onClick={onClose}
              className="px-6 py-2 text-gray-600 hover:bg-gray-200 rounded-lg font-medium transition-colors"
            >
              Cancelar
            </button>
            <button 
              onClick={handleSave}
              className="px-6 py-2 bg-blue-600 hover:bg-blue-700 text-white rounded-lg font-medium transition-colors"
            >
              Salvar
            </button>
          </div>
        </div>

        {/* Delete Confirmation Modal */}
        {showDeleteConfirm && (
          <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-[110]">
            <div className="bg-white rounded-2xl shadow-xl p-6 max-w-sm mx-4">
              <div className="flex items-center gap-3 mb-4">
                <div className="w-12 h-12 rounded-full bg-red-100 flex items-center justify-center">
                  <Trash2 size={24} className="text-red-600" />
                </div>
                <h3 className="text-lg font-bold text-gray-800">Deletar Tarefa?</h3>
              </div>
              <p className="text-gray-600 mb-6">
                Esta ação é permanente. A tarefa e todos os seus slots agendados serão removidos.
              </p>
              <div className="flex gap-3 justify-end">
                <button
                  onClick={() => setShowDeleteConfirm(false)}
                  className="px-4 py-2 border border-gray-300 rounded-lg text-gray-700 hover:bg-gray-50 font-medium transition"
                >
                  Cancelar
                </button>
                <button
                  onClick={handleDelete}
                  className="px-4 py-2 bg-red-600 hover:bg-red-700 text-white rounded-lg font-medium transition"
                >
                  Deletar
                </button>
              </div>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}