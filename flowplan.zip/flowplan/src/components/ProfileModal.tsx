import { useState, useEffect } from 'react';
import { useStore } from '../store/useStore';
import { X, Plus, Trash2, AlertCircle } from 'lucide-react';
import { v4 as uuidv4 } from 'uuid';
import { Pause, DayConfig } from '../store/types';

interface ProfileModalProps {
  profileId: string | null;
  onClose: () => void;
}

const dayNames = ['Domingo', 'Segunda', 'Terça', 'Quarta', 'Quinta', 'Sexta', 'Sábado'];

export default function ProfileModal({ profileId, onClose }: ProfileModalProps) {
  const { profiles, addProfile, updateProfile, deleteProfile } = useStore();
  
  const [name, setName] = useState('');
  const [interval, setInterval] = useState<number>(5);
  const [standardStart, setStandardStart] = useState('08:00');
  const [standardEnd, setStandardEnd] = useState('18:00');
  const [standardPauses, setStandardPauses] = useState<Pause[]>([]);
  const [days, setDays] = useState<{ [key: number]: DayConfig }>({
    0: { active: false, type: 'standard' },
    1: { active: true, type: 'standard' },
    2: { active: true, type: 'standard' },
    3: { active: true, type: 'standard' },
    4: { active: true, type: 'standard' },
    5: { active: true, type: 'standard' },
    6: { active: false, type: 'standard' },
  });

  const [error, setError] = useState<string | null>(null);
  const [showDeleteConfirm, setShowDeleteConfirm] = useState(false);

  useEffect(() => {
    if (profileId) {
      const profile = profiles.find(p => p.id === profileId);
      if (profile) {
        setName(profile.name);
        setInterval(profile.interval);
        setStandardStart(profile.standardStart);
        setStandardEnd(profile.standardEnd);
        setStandardPauses(profile.standardPauses);
        setDays(profile.days);
      }
    }
  }, [profileId, profiles]);

  const validateTimes = (start: string, end: string, pauses: Pause[]) => {
    if (start >= end) {
      return "A hora inicial deve ser antes da hora final";
    }
    
    for (let i = 0; i < pauses.length; i++) {
      const p = pauses[i];
      if (p.start >= p.end) {
        return "A hora inicial da pausa deve ser antes da hora final";
      }
      if (p.start < start || p.end > end) {
        return "A pausa precisa estar dentro do horário do dia";
      }
      for (let j = 0; j < pauses.length; j++) {
        if (i !== j) {
          const p2 = pauses[j];
          if (p.start < p2.end && p.end > p2.start) {
            return "Esta pausa se sobrepõe a outra pausa existente";
          }
        }
      }
    }
    return null;
  };

  const handleSave = () => {
    setError(null);
    if (!name.trim()) {
      setError('Preencha o nome do perfil');
      return;
    }

    const standardError = validateTimes(standardStart, standardEnd, standardPauses);
    if (standardError) {
      setError(`Horário padrão: ${standardError}`);
      return;
    }

    for (let i = 0; i < 7; i++) {
      const day = days[i];
      if (day.active && day.type === 'custom') {
        if (!day.start || !day.end) {
          setError(`Dia ${dayNames[i]} precisa de horário inicial e final`);
          return;
        }
        const dayError = validateTimes(day.start, day.end, day.pauses || []);
        if (dayError) {
          setError(`Dia ${dayNames[i]}: ${dayError}`);
          return;
        }
      }
    }

    const data = {
      name: name.trim(),
      interval,
      standardStart,
      standardEnd,
      standardPauses,
      days
    };

    if (profileId) {
      updateProfile(profileId, data);
    } else {
      addProfile(data);
    }
    onClose();
  };

  const handleDelete = () => {
    if (profileId) {
      deleteProfile(profileId);
      setShowDeleteConfirm(false);
      onClose();
    }
  };

  return (
    <div className="fixed inset-0 bg-black/50 z-[100] flex justify-center items-center p-4">
      <div className="bg-white w-full max-w-2xl rounded-xl shadow-xl flex flex-col max-h-[90vh]">
        <div className="flex justify-between items-center p-6 border-b border-gray-100 shrink-0">
          <h2 className="text-xl font-bold text-gray-800">{profileId ? 'Editar Perfil de Horário' : 'Novo Perfil'}</h2>
          <button onClick={onClose} className="p-2 hover:bg-gray-100 rounded-full text-gray-500">
            <X size={20} />
          </button>
        </div>

        <div className="overflow-y-auto p-6 flex-1 space-y-6">
          {error && (
            <div className="p-3 bg-red-50 text-red-600 rounded text-sm border border-red-100 font-medium">
              {error}
            </div>
          )}

          <div className="grid grid-cols-2 gap-4">
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">Nome do perfil</label>
              <input 
                type="text" 
                value={name}
                onChange={(e) => setName(e.target.value)}
                className="w-full border border-gray-300 rounded-lg px-3 py-2 outline-none focus:ring-2 focus:ring-blue-500"
                placeholder="Ex: Trabalho, Estudo..."
              />
            </div>
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">Intervalo entre tarefas (min)</label>
              <input 
                type="number" 
                value={interval}
                onChange={(e) => setInterval(parseInt(e.target.value) || 0)}
                className="w-full border border-gray-300 rounded-lg px-3 py-2 outline-none focus:ring-2 focus:ring-blue-500"
                min="0"
              />
            </div>
          </div>

          <div className="border border-gray-200 rounded-lg p-4 bg-gray-50">
            <h3 className="font-semibold text-gray-800 mb-4">Horário Padrão</h3>
            
            <div className="flex gap-4 mb-4">
              <div>
                <label className="block text-xs font-medium text-gray-600 mb-1">Hora inicial</label>
                <input 
                  type="time" 
                  value={standardStart}
                  onChange={(e) => setStandardStart(e.target.value)}
                  className="border border-gray-300 rounded-lg px-3 py-2 outline-none focus:ring-2 focus:ring-blue-500"
                />
              </div>
              <div>
                <label className="block text-xs font-medium text-gray-600 mb-1">Hora final</label>
                <input 
                  type="time" 
                  value={standardEnd}
                  onChange={(e) => setStandardEnd(e.target.value)}
                  className="border border-gray-300 rounded-lg px-3 py-2 outline-none focus:ring-2 focus:ring-blue-500"
                />
              </div>
            </div>

            <div>
              <div className="flex items-center justify-between mb-2">
                <label className="block text-sm font-medium text-gray-700">Pausas do horário padrão</label>
                <button 
                  onClick={() => setStandardPauses([...standardPauses, { id: uuidv4(), start: '12:00', end: '13:00', label: '' }])}
                  className="text-xs flex items-center gap-1 text-blue-600 hover:text-blue-700"
                >
                  <Plus size={14} /> Adicionar pausa
                </button>
              </div>
              {standardPauses.length === 0 && (
                <p className="text-sm text-gray-500 italic">Nenhuma pausa configurada.</p>
              )}
              <div className="space-y-2">
                {standardPauses.map((pause, index) => (
                  <div key={pause.id} className="flex gap-2 items-center bg-white p-2 rounded border border-gray-200">
                    <input 
                      type="text" 
                      placeholder="Rótulo (ex: Almoço)"
                      value={pause.label || ''}
                      onChange={(e) => {
                        const np = [...standardPauses];
                        np[index].label = e.target.value;
                        setStandardPauses(np);
                      }}
                      className="border border-gray-300 rounded px-2 py-1 text-sm outline-none w-1/3"
                    />
                    <input 
                      type="time" 
                      value={pause.start}
                      onChange={(e) => {
                        const np = [...standardPauses];
                        np[index].start = e.target.value;
                        setStandardPauses(np);
                      }}
                      className="border border-gray-300 rounded px-2 py-1 text-sm outline-none"
                    />
                    <span className="text-gray-400">-</span>
                    <input 
                      type="time" 
                      value={pause.end}
                      onChange={(e) => {
                        const np = [...standardPauses];
                        np[index].end = e.target.value;
                        setStandardPauses(np);
                      }}
                      className="border border-gray-300 rounded px-2 py-1 text-sm outline-none"
                    />
                    <button 
                      onClick={() => setStandardPauses(standardPauses.filter(p => p.id !== pause.id))}
                      className="text-red-500 hover:text-red-700 p-1 ml-auto"
                    >
                      <Trash2 size={16} />
                    </button>
                  </div>
                ))}
              </div>
            </div>
          </div>

          <div className="border border-gray-200 rounded-lg p-4 bg-white">
            <h3 className="font-semibold text-gray-800 mb-4">Dias da Semana</h3>
            
            <div className="space-y-4">
              {[1, 2, 3, 4, 5, 6, 0].map(dayIndex => {
                const config = days[dayIndex];
                
                return (
                  <div key={dayIndex} className={`p-3 rounded border ${config.active ? 'border-blue-200 bg-blue-50/30' : 'border-gray-200 bg-gray-50'}`}>
                    <div className="flex items-center justify-between mb-2">
                      <div className="flex items-center gap-3">
                        <input 
                          type="checkbox" 
                          checked={config.active}
                          onChange={(e) => {
                            setDays({
                              ...days,
                              [dayIndex]: { ...config, active: e.target.checked }
                            });
                          }}
                          className="w-4 h-4 text-blue-600 rounded"
                        />
                        <span className={`font-medium ${config.active ? 'text-gray-800' : 'text-gray-400'}`}>
                          {dayNames[dayIndex]}
                        </span>
                      </div>
                      
                      {config.active && (
                        <select 
                          value={config.type}
                          onChange={(e) => {
                            setDays({
                              ...days,
                              [dayIndex]: { 
                                ...config, 
                                type: e.target.value as 'standard' | 'custom',
                                start: e.target.value === 'custom' ? standardStart : undefined,
                                end: e.target.value === 'custom' ? standardEnd : undefined,
                                pauses: e.target.value === 'custom' ? [] : undefined
                              }
                            });
                          }}
                          className="text-sm border-gray-300 rounded outline-none p-1"
                        >
                          <option value="standard">Horário Padrão</option>
                          <option value="custom">Customizado</option>
                        </select>
                      )}
                    </div>

                    {config.active && config.type === 'custom' && (
                      <div className="mt-3 pl-7 space-y-3">
                        <div className="flex gap-4">
                          <div>
                            <label className="block text-xs text-gray-500 mb-1">Início</label>
                            <input 
                              type="time" 
                              value={config.start || standardStart}
                              onChange={(e) => setDays({
                                ...days,
                                [dayIndex]: { ...config, start: e.target.value }
                              })}
                              className="border border-gray-300 rounded px-2 py-1 text-sm"
                            />
                          </div>
                          <div>
                            <label className="block text-xs text-gray-500 mb-1">Fim</label>
                            <input 
                              type="time" 
                              value={config.end || standardEnd}
                              onChange={(e) => setDays({
                                ...days,
                                [dayIndex]: { ...config, end: e.target.value }
                              })}
                              className="border border-gray-300 rounded px-2 py-1 text-sm"
                            />
                          </div>
                        </div>

                        <div>
                          <div className="flex items-center gap-2 mb-1">
                            <span className="text-xs font-medium text-gray-600">Pausas do dia</span>
                            <button 
                              onClick={() => {
                                const currentPauses = config.pauses || [];
                                setDays({
                                  ...days,
                                  [dayIndex]: { 
                                    ...config, 
                                    pauses: [...currentPauses, { id: uuidv4(), start: '12:00', end: '13:00', label: '' }] 
                                  }
                                });
                              }}
                              className="text-[10px] text-blue-600 hover:text-blue-700"
                            >
                              + Adicionar
                            </button>
                          </div>
                          <div className="space-y-2">
                            {(config.pauses || []).map((pause, pIndex) => (
                              <div key={pause.id} className="flex gap-2 items-center">
                                <input 
                                  type="text" 
                                  placeholder="Rótulo"
                                  value={pause.label || ''}
                                  onChange={(e) => {
                                    const np = [...(config.pauses || [])];
                                    np[pIndex].label = e.target.value;
                                    setDays({...days, [dayIndex]: {...config, pauses: np}});
                                  }}
                                  className="border border-gray-300 rounded px-2 py-1 text-xs w-24"
                                />
                                <input 
                                  type="time" 
                                  value={pause.start}
                                  onChange={(e) => {
                                    const np = [...(config.pauses || [])];
                                    np[pIndex].start = e.target.value;
                                    setDays({...days, [dayIndex]: {...config, pauses: np}});
                                  }}
                                  className="border border-gray-300 rounded px-2 py-1 text-xs"
                                />
                                <span className="text-gray-400">-</span>
                                <input 
                                  type="time" 
                                  value={pause.end}
                                  onChange={(e) => {
                                    const np = [...(config.pauses || [])];
                                    np[pIndex].end = e.target.value;
                                    setDays({...days, [dayIndex]: {...config, pauses: np}});
                                  }}
                                  className="border border-gray-300 rounded px-2 py-1 text-xs"
                                />
                                <button 
                                  onClick={() => {
                                    const np = (config.pauses || []).filter(p => p.id !== pause.id);
                                    setDays({...days, [dayIndex]: {...config, pauses: np}});
                                  }}
                                  className="text-red-500 hover:text-red-700"
                                >
                                  <Trash2 size={14} />
                                </button>
                              </div>
                            ))}
                          </div>
                        </div>
                      </div>
                    )}
                  </div>
                );
              })}
            </div>
          </div>
        </div>

        <div className="p-4 border-t border-gray-100 flex justify-between gap-3 shrink-0 bg-gray-50 rounded-b-xl">
          <div>
            {profileId && (
              <button 
                onClick={() => setShowDeleteConfirm(true)}
                className="px-4 py-2 bg-red-600 hover:bg-red-700 text-white rounded-lg font-medium transition-colors"
              >
                Excluir
              </button>
            )}
          </div>
          <div className="flex gap-3">
            <button 
              onClick={onClose}
              className="px-4 py-2 text-gray-600 hover:bg-gray-200 rounded-lg font-medium transition-colors"
            >
              Cancelar
            </button>
            <button 
              onClick={handleSave}
              className="px-4 py-2 bg-blue-600 hover:bg-blue-700 text-white rounded-lg font-medium transition-colors"
            >
              Salvar
            </button>
          </div>
        </div>

        {/* Delete Confirmation Modal */}
        {showDeleteConfirm && (
          <div className="fixed inset-0 bg-black/50 z-[101] flex justify-center items-center p-4">
            <div className="bg-white rounded-xl shadow-xl max-w-sm">
              <div className="p-6 space-y-4">
                <div className="flex items-center gap-3">
                  <div className="p-3 bg-red-50 rounded-lg">
                    <AlertCircle size={24} className="text-red-600" />
                  </div>
                  <div>
                    <h3 className="font-bold text-gray-800">Excluir Perfil</h3>
                    <p className="text-sm text-gray-500">Esta ação é permanente</p>
                  </div>
                </div>
                
                <p className="text-gray-700">
                  Tem certeza que deseja excluir o perfil <strong>"{name}"</strong>? Todos os dados deste perfil serão removidos.
                </p>
              </div>
              
              <div className="flex gap-3 p-4 border-t border-gray-100 bg-gray-50 rounded-b-xl">
                <button 
                  onClick={() => setShowDeleteConfirm(false)}
                  className="flex-1 px-4 py-2 text-gray-600 hover:bg-gray-200 rounded-lg font-medium transition-colors"
                >
                  Cancelar
                </button>
                <button 
                  onClick={handleDelete}
                  className="flex-1 px-4 py-2 bg-red-600 hover:bg-red-700 text-white rounded-lg font-medium transition-colors"
                >
                  Excluir Perfil
                </button>
              </div>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}