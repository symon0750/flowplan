import { useMemo, useEffect, useState, useRef } from 'react';
import { format, isSameDay, parseISO, startOfDay, addDays } from 'date-fns';
import { ptBR } from 'date-fns/locale';
import { Task, Slot } from '../store/types';
import { useStore } from '../store/useStore';
import { X, Trash2 } from 'lucide-react';

interface AgendaGridProps {
  date: Date;
  daysCount: number; // 1 for daily, 7 for weekly
  tasks: Task[];
  slots: Slot[];
  onTaskClick: (taskId: string) => void;
  onTaskDelete?: (taskId: string) => void;
  onNavigate?: (direction: 'prev' | 'next') => void;
}

const HOURS = Array.from({ length: 24 }, (_, i) => i);

export default function AgendaGrid({ date, daysCount, tasks, slots, onTaskClick, onTaskDelete, onNavigate }: AgendaGridProps) {
  const { tags, updateTask, deleteTask } = useStore();
  const [currentTime, setCurrentTime] = useState(new Date());
  const [hoveredSlotId, setHoveredSlotId] = useState<string | null>(null);
  const [deleteConfirm, setDeleteConfirm] = useState<string | null>(null);
  const gridRef = useRef<HTMLDivElement>(null);
  const [touchStart, setTouchStart] = useState<number | null>(null);

  useEffect(() => {
    const timer = setInterval(() => setCurrentTime(new Date()), 60000);
    
    // Initial scroll to current time or 8am
    if (gridRef.current) {
      const currentHour = new Date().getHours();
      const scrollHour = currentHour > 2 ? currentHour - 2 : 0;
      gridRef.current.scrollTop = scrollHour * 60; // 60px per hour
    }

    // Swipe handlers
    const handleTouchStart = (e: TouchEvent) => {
      setTouchStart(e.touches[0].clientX);
    };

    const handleTouchEnd = (e: TouchEvent) => {
      if (touchStart !== null) {
        const touchEnd = e.changedTouches[0].clientX;
        const diff = touchStart - touchEnd;
        
        // Swipe left = next, Swipe right = prev (minimum 50px)
        if (Math.abs(diff) > 50) {
          if (diff > 0) {
            onNavigate?.('next');
          } else {
            onNavigate?.('prev');
          }
        }
        setTouchStart(null);
      }
    };

    const element = gridRef.current;
    if (element) {
      element.addEventListener('touchstart', handleTouchStart);
      element.addEventListener('touchend', handleTouchEnd);
    }

    return () => {
      clearInterval(timer);
      if (element) {
        element.removeEventListener('touchstart', handleTouchStart);
        element.removeEventListener('touchend', handleTouchEnd);
      }
    };
  }, [touchStart, onNavigate]);

  const days = useMemo(() => {
    const start = startOfDay(date);
    return Array.from({ length: daysCount }, (_, i) => addDays(start, i));
  }, [date, daysCount]);

  const toggleTask = (e: React.MouseEvent, task: Task) => {
    e.stopPropagation();
    updateTask(task.id, { status: task.status === 'completed' ? 'pending' : 'completed' });
  };

  const handleDeleteTask = (taskId: string) => {
    deleteTask(taskId);
    setDeleteConfirm(null);
    onTaskDelete?.(taskId);
  };

  const getSlotStyle = (slot: Slot, dayDate: Date, task: Task) => {
    const start = parseISO(slot.start);
    const end = parseISO(slot.end);
    
    if (!isSameDay(start, dayDate)) return null;

    const startMinutes = start.getHours() * 60 + start.getMinutes();
    const exactDuration = (end.getTime() - start.getTime()) / 60000;
    
    const tag = tags.find(t => t.id === task.tagId);
    const bgColor = tag ? tag.color : '#3b82f6';
    const isCompleted = task.status === 'completed';

    return {
      top: `${(startMinutes / 60) * 60}px`, // 60px per hour
      height: `${(exactDuration / 60) * 60}px`,
      backgroundColor: isCompleted ? '#e5e7eb' : `${bgColor}33`,
      borderColor: isCompleted ? '#9ca3af' : bgColor,
      color: isCompleted ? '#6b7280' : '#1e293b',
      borderLeftWidth: '4px',
      borderLeftColor: isCompleted ? '#9ca3af' : bgColor,
    };
  };

  // Renderiza slots ou eventos fixos para um dia
  const getBlocksForDay = (dayDate: Date) => {
    const dayBlocks: {
      id: string;
      type: 'slot' | 'fixed';
      top: string;
      height: string;
      backgroundColor: string;
      borderColor: string;
      color: string;
      task: Task;
      slot?: Slot;
    }[] = [];

    // Slots normais
    slots
      .filter(slot => isSameDay(parseISO(slot.start), dayDate))
      .forEach(slot => {
        const task = tasks.find(t => t.id === slot.taskId);
        if (!task) return;
        
        const style = getSlotStyle(slot, dayDate, task);
        if (!style) return;

        dayBlocks.push({
          id: slot.id,
          type: 'slot',
          top: style.top as string,
          height: style.height as string,
          backgroundColor: style.backgroundColor as string,
          borderColor: style.borderColor as string,
          color: style.color as string,
          task,
          slot,
        });
      });

    // Eventos fixos (que não têm slots)
    tasks
      .filter(task => task.isFixed && task.fixedStart && task.fixedEnd && !task.isPlanned)
      .filter(task => isSameDay(parseISO(task.fixedStart!), dayDate))
      .forEach(task => {
        const start = parseISO(task.fixedStart!);
        const end = parseISO(task.fixedEnd!);
        const startMinutes = start.getHours() * 60 + start.getMinutes();
        const exactDuration = (end.getTime() - start.getTime()) / 60000;
        
        const tag = tags.find(t => t.id === task.tagId);
        const bgColor = tag ? tag.color : '#3b82f6';
        const isCompleted = task.status === 'completed';

        dayBlocks.push({
          id: `fixed-${task.id}`,
          type: 'fixed',
          top: `${(startMinutes / 60) * 60}px`,
          height: `${(exactDuration / 60) * 60}px`,
          backgroundColor: isCompleted ? '#e5e7eb' : `${bgColor}33`,
          borderColor: isCompleted ? '#9ca3af' : bgColor,
          color: isCompleted ? '#6b7280' : '#1e293b',
          task,
        });
      });

    return dayBlocks;
  };

  return (
    <div className="flex flex-col h-full bg-white relative">
      {/* Header com dias */}
      <div className="flex border-b border-gray-200 shrink-0 bg-white sticky top-0 z-10">
        <div className="w-14 shrink-0 border-r border-gray-200"></div>
        <div className="flex flex-1">
          {days.map(day => {
            const isTdy = isSameDay(day, new Date());
            return (
              <div 
                key={day.toISOString()} 
                className={`flex-1 flex flex-col items-center py-2 border-r border-gray-100 ${isTdy ? 'bg-blue-50' : ''}`}
              >
                <span className={`text-xs font-medium ${isTdy ? 'text-blue-600' : 'text-gray-500'}`}>
                  {format(day, 'EEE', { locale: ptBR })}
                </span>
                <span className={`text-lg font-bold mt-1 w-8 h-8 flex items-center justify-center rounded-full ${isTdy ? 'bg-blue-600 text-white' : 'text-gray-800'}`}>
                  {format(day, 'd')}
                </span>
              </div>
            );
          })}
        </div>
      </div>

      {/* Grid de horários */}
      <div ref={gridRef} className="flex-1 overflow-y-auto overflow-x-auto relative bg-white">
        <div className="flex relative" style={{ minHeight: `${24 * 60}px` }}>
          {/* Coluna de horários */}
          <div className="w-14 shrink-0 border-r border-gray-200 bg-gray-50 sticky left-0 z-10">
            {HOURS.map(hour => (
              <div key={hour} className="h-[60px] relative border-b border-gray-200 flex items-start justify-end pr-2">
                <span className="text-xs font-medium text-gray-500">
                  {hour.toString().padStart(2, '0')}:00
                </span>
              </div>
            ))}
          </div>

          {/* Linhas da grade */}
          <div className="absolute top-0 right-0 left-14 bottom-0 flex flex-col pointer-events-none">
            {HOURS.map(hour => (
              <div key={hour} className="h-[60px] border-b border-gray-100 w-full" />
            ))}
          </div>

          {/* Colunas dos dias */}
          <div className="flex flex-1 relative" style={{ minWidth: daysCount === 7 ? '100%' : 'auto' }}>
            {days.map(day => {
              const isTdy = isSameDay(day, new Date());
              const dayBlocks = getBlocksForDay(day);

              return (
                <div 
                  key={day.toISOString()} 
                  className={`flex-1 border-r border-gray-100 relative ${isTdy ? 'bg-blue-50/10' : ''}`}
                  style={{ minWidth: daysCount === 7 ? `calc(100% / 7)` : '100%' }}
                >
                  {/* Linha de hora atual */}
                  {isTdy && (
                    <div 
                      className="absolute left-0 right-0 border-t-2 border-red-500 z-20 flex items-center"
                      style={{ top: `${(currentTime.getHours() * 60 + currentTime.getMinutes())}px` }}
                    >
                      <div className="absolute -left-2 w-2 h-2 rounded-full bg-red-500" />
                      <span className="absolute -left-12 text-[10px] font-bold text-red-600 bg-white px-1">
                        {format(currentTime, 'HH:mm')}
                      </span>
                    </div>
                  )}

                  {/* Blocos de tarefas */}
                  {dayBlocks.map(block => (
                    <div
                      key={block.id}
                      className={`absolute left-1 right-1 rounded-md px-2 py-1 overflow-hidden text-xs cursor-pointer transition-all shadow-sm group border-l-4 ${
                        block.type === 'fixed' ? 'ring-1 ring-orange-300' : ''
                      }`}
                      style={{
                        top: block.top,
                        height: block.height,
                        backgroundColor: block.backgroundColor,
                        borderLeftColor: block.borderColor,
                        color: block.color,
                      }}
                      onMouseEnter={() => setHoveredSlotId(block.id)}
                      onMouseLeave={() => setHoveredSlotId(null)}
                      onClick={() => onTaskClick(block.task.id)}
                    >
                      <div className="flex items-start gap-1 justify-between h-full">
                        <div className="font-medium truncate flex-1 leading-tight">
                          {block.task.name}
                        </div>
                        <div className={`shrink-0 flex gap-0.5 ${hoveredSlotId === block.id ? 'opacity-100' : 'opacity-0'} transition-opacity`}>
                          <button 
                            onClick={(e) => {
                              e.stopPropagation();
                              setDeleteConfirm(block.task.id);
                            }}
                            className="w-4 h-4 hover:bg-red-200 rounded flex items-center justify-center"
                            title="Deletar tarefa"
                          >
                            <Trash2 size={12} className="text-red-600" />
                          </button>
                          <button 
                            onClick={(e) => toggleTask(e, block.task)}
                            className={`w-4 h-4 rounded-full border-2 flex items-center justify-center transition-colors ${
                              block.task.status === 'completed'
                                ? 'bg-gray-400 border-gray-400'
                                : 'border-current hover:bg-current/10'
                            }`}
                            title="Marcar como concluída"
                          >
                            {block.task.status === 'completed' && <span className="text-white text-[10px]">✓</span>}
                          </button>
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              );
            })}
          </div>
        </div>
      </div>

      {/* Modal de confirmação de exclusão */}
      {deleteConfirm && (
        <div className="fixed inset-0 bg-black/50 z-50 flex items-center justify-center">
          <div className="bg-white rounded-lg shadow-xl p-6 max-w-sm">
            <div className="flex items-center gap-3 mb-4">
              <div className="w-10 h-10 rounded-full bg-red-100 flex items-center justify-center">
                <Trash2 size={20} className="text-red-600" />
              </div>
              <h3 className="text-lg font-bold text-gray-800">Deletar tarefa?</h3>
            </div>
            <p className="text-sm text-gray-600 mb-6">
              A tarefa será removida permanentemente. Esta ação não pode ser desfeita.
            </p>
            <div className="flex gap-2 justify-end">
              <button
                onClick={() => setDeleteConfirm(null)}
                className="px-4 py-2 rounded-lg border border-gray-300 text-gray-700 hover:bg-gray-50 font-medium"
              >
                Cancelar
              </button>
              <button
                onClick={() => handleDeleteTask(deleteConfirm)}
                className="px-4 py-2 rounded-lg bg-red-600 text-white hover:bg-red-700 font-medium"
              >
                Deletar
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
