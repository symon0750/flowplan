import { useState, useEffect } from 'react';
import { useStore } from '../store/useStore';
import { X, AlertCircle } from 'lucide-react';

interface TagModalProps {
  tagId: string | null;
  onClose: () => void;
}

const colors = [
  '#ef4444', '#f97316', '#f59e0b', '#84cc16', '#22c55e', '#10b981', 
  '#06b6d4', '#0ea5e9', '#3b82f6', '#6366f1', '#8b5cf6', '#a855f7', '#d946ef', '#ec4899'
];

export default function TagModal({ tagId, onClose }: TagModalProps) {
  const { tags, addTag, updateTag, deleteTag } = useStore();
  const [name, setName] = useState('');
  const [color, setColor] = useState(colors[0]);
  const [error, setError] = useState<string | null>(null);
  const [showDeleteConfirm, setShowDeleteConfirm] = useState(false);

  useEffect(() => {
    if (tagId) {
      const tag = tags.find(t => t.id === tagId);
      if (tag) {
        setName(tag.name);
        setColor(tag.color);
      }
    }
  }, [tagId, tags]);

  const handleSave = () => {
    setError(null);
    
    if (!name.trim()) {
      setError('Preencha o nome da tag');
      return;
    }
    
    const duplicateName = tags.find(t => t.name.toLowerCase() === name.trim().toLowerCase() && t.id !== tagId);
    if (duplicateName) {
      setError('Já existe uma tag com esse nome');
      return;
    }
    
    const duplicateColor = tags.find(t => t.color === color && t.id !== tagId);
    if (duplicateColor) {
      setError('Já existe uma tag com essa cor');
      return;
    }

    if (tagId) {
      updateTag(tagId, { name: name.trim(), color });
    } else {
      addTag({ name: name.trim(), color });
    }
    onClose();
  };

  const handleDelete = () => {
    if (tagId) {
      deleteTag(tagId);
      setShowDeleteConfirm(false);
      onClose();
    }
  };

  return (
    <div className="fixed inset-0 bg-black/50 z-[100] flex justify-center items-center p-4">
      <div className="bg-white w-full max-w-sm rounded-xl p-6 shadow-xl">
        <div className="flex justify-between items-center mb-6">
          <h2 className="text-xl font-bold text-gray-800">{tagId ? 'Editar Tag' : 'Nova Tag'}</h2>
          <button onClick={onClose} className="p-2 hover:bg-gray-100 rounded-full text-gray-500">
            <X size={20} />
          </button>
        </div>

        {error && (
          <div className="mb-4 p-3 bg-red-50 text-red-600 rounded text-sm border border-red-100">
            {error}
          </div>
        )}

        <div className="space-y-4">
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">Nome da tag</label>
            <input 
              type="text" 
              value={name}
              onChange={(e) => setName(e.target.value)}
              className="w-full border border-gray-300 rounded-lg px-3 py-2 focus:ring-2 focus:ring-blue-500 outline-none"
              placeholder="Ex: Urgente"
            />
          </div>

          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">Cor da tag</label>
            <div className="grid grid-cols-7 gap-2">
              {colors.map(c => (
                <button
                  key={c}
                  onClick={() => setColor(c)}
                  className={`w-8 h-8 rounded-full focus:outline-none transition-transform ${color === c ? 'ring-2 ring-offset-2 ring-gray-400 scale-110' : ''}`}
                  style={{ backgroundColor: c }}
                />
              ))}
            </div>
          </div>
        </div>

        <div className="mt-8 flex justify-between gap-3">
          <div>
            {tagId && (
              <button 
                onClick={() => setShowDeleteConfirm(true)}
                className="px-4 py-2 bg-red-600 hover:bg-red-700 text-white rounded-lg font-medium transition-colors"
              >
                Excluir
              </button>
            )}
          </div>
          <div className="flex gap-3">
            <button 
              onClick={onClose}
              className="px-4 py-2 text-gray-600 hover:bg-gray-100 rounded-lg font-medium transition-colors"
            >
              Cancelar
            </button>
            <button 
              onClick={handleSave}
              className="px-4 py-2 bg-blue-600 hover:bg-blue-700 text-white rounded-lg font-medium transition-colors"
            >
              Salvar
            </button>
          </div>
        </div>

        {/* Delete Confirmation Modal */}
        {showDeleteConfirm && (
          <div className="fixed inset-0 bg-black/50 z-[101] flex justify-center items-center p-4">
            <div className="bg-white rounded-xl shadow-xl max-w-sm">
              <div className="p-6 space-y-4">
                <div className="flex items-center gap-3">
                  <div className="p-3 bg-red-50 rounded-lg">
                    <AlertCircle size={24} className="text-red-600" />
                  </div>
                  <div>
                    <h3 className="font-bold text-gray-800">Excluir Tag</h3>
                    <p className="text-sm text-gray-500">Esta ação é permanente</p>
                  </div>
                </div>
                
                <p className="text-gray-700">
                  Tem certeza que deseja excluir a tag <strong>"{name}"</strong>? Todas as tarefas que usam essa tag terão a tag removida.
                </p>
              </div>
              
              <div className="flex gap-3 p-4 border-t border-gray-100 bg-gray-50 rounded-b-xl">
                <button 
                  onClick={() => setShowDeleteConfirm(false)}
                  className="flex-1 px-4 py-2 text-gray-600 hover:bg-gray-200 rounded-lg font-medium transition-colors"
                >
                  Cancelar
                </button>
                <button 
                  onClick={handleDelete}
                  className="flex-1 px-4 py-2 bg-red-600 hover:bg-red-700 text-white rounded-lg font-medium transition-colors"
                >
                  Excluir Tag
                </button>
              </div>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}
