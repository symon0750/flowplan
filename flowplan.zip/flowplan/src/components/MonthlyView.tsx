import { useMemo } from 'react';
import { format, isSameDay, startOfMonth, endOfMonth, startOfWeek, endOfWeek, addDays, isSameMonth, parseISO } from 'date-fns';
import { ptBR } from 'date-fns/locale';
import { Task, Slot } from '../store/types';
import { useStore } from '../store/useStore';

interface MonthlyViewProps {
  date: Date;
  tasks: Task[];
  slots: Slot[];
  onDayClick: (date: Date) => void;
}

export default function MonthlyView({ date, tasks, slots, onDayClick }: MonthlyViewProps) {
  const { tags } = useStore();
  
  // Get tasks for a specific day using real slots
  const getTasksForDay = (dayDate: Date) => {
    const tasksByDay = new Set<string>();
    
    // Add tasks from slots
    slots.forEach(slot => {
      if (isSameDay(parseISO(slot.start), dayDate)) {
        tasksByDay.add(slot.taskId);
      }
    });
    
    // Add tasks with fixed schedule
    tasks.forEach(task => {
      if (task.isFixed && task.fixedStart && !task.isPlanned) {
        if (isSameDay(parseISO(task.fixedStart), dayDate)) {
          tasksByDay.add(task.id);
        }
      }
    });
    
    return Array.from(tasksByDay).map(taskId => tasks.find(t => t.id === taskId)!).filter(Boolean);
  };

  const days = useMemo(() => {
    const monthStart = startOfMonth(date);
    const monthEnd = endOfMonth(monthStart);
    const startDate = startOfWeek(monthStart);
    const endDate = endOfWeek(monthEnd);

    const dateFormat = "d";
    const rows = [];

    let daysArr = [];
    let day = startDate;
    let formattedDate = "";

    while (day <= endDate) {
      for (let i = 0; i < 7; i++) {
        formattedDate = format(day, dateFormat);
        const cloneDay = day;
        const dayTasks = getTasksForDay(cloneDay);
        
        daysArr.push(
          <div
            className={`min-h-[80px] border-r border-b border-gray-100 p-1 cursor-pointer transition-colors hover:bg-gray-50 flex flex-col ${!isSameMonth(day, monthStart) ? 'bg-gray-50 text-gray-400' : 'bg-white text-gray-800'} ${isSameDay(day, new Date()) ? 'bg-blue-50/50 border-blue-200' : ''}`}
            key={day.toISOString()}
            onClick={() => onDayClick(cloneDay)}
          >
            <div className="flex justify-between items-center mb-1">
              <span className={`text-xs font-semibold w-6 h-6 flex items-center justify-center rounded-full ${isSameDay(day, new Date()) ? 'bg-blue-600 text-white' : ''}`}>
                {formattedDate}
              </span>
              {dayTasks.length > 0 && (
                <span className="text-[10px] font-bold text-blue-600 bg-blue-100 px-1.5 rounded-full">
                  {dayTasks.length}
                </span>
              )}
            </div>
            
            <div className="flex flex-wrap gap-1 mt-auto">
              {dayTasks.slice(0, 5).map(task => {
                const tag = tags.find(tg => tg.id === task.tagId);
                return (
                  <div 
                    key={task.id} 
                    className="flex items-center gap-1 px-2 py-0.5 rounded text-[10px] font-medium truncate"
                    style={{ 
                      backgroundColor: `${tag?.color || '#3b82f6'}20`,
                      color: tag?.color || '#3b82f6',
                      borderLeft: `3px solid ${tag?.color || '#3b82f6'}`
                    }}
                    title={task.name}
                  >
                    <span className="truncate">{task.name}</span>
                  </div>
                );
              })}
              {dayTasks.length > 5 && (
                <span className="text-[10px] text-gray-500 font-semibold px-2">
                  +{dayTasks.length - 5} mais
                </span>
              )}
            </div>
          </div>
        );
        day = addDays(day, 1);
      }
      rows.push(
        <div className="flex w-full" key={day.toISOString()}>
          {daysArr}
        </div>
      );
      daysArr = [];
    }
    return rows;
  }, [date, tasks, slots, tags, onDayClick]);

  return (
    <div className="flex flex-col h-full bg-white">
      <div className="flex border-b border-gray-200 shrink-0 bg-gray-50">
        {['Dom', 'Seg', 'Ter', 'Qua', 'Qui', 'Sex', 'Sáb'].map((day) => (
          <div key={day} className="flex-1 text-center py-2 text-xs font-medium text-gray-500 uppercase">
            {day}
          </div>
        ))}
      </div>
      <div className="flex flex-col flex-1 overflow-y-auto pb-24">
        {days}
      </div>
    </div>
  );
}
