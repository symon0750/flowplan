import { useState, useEffect } from 'react';
import { useStore } from '../store/useStore';
import { X, Calendar, Tag as TagIcon, Settings2, AlertCircle } from 'lucide-react';
import { Project } from '../store/types';

interface ProjectModalProps {
  projectId?: string | null;
  onClose: () => void;
}

export default function ProjectModal({ projectId, onClose }: ProjectModalProps) {
  const { projects, tags, profiles, addProject, updateProject, deleteProject } = useStore();
  
  const [name, setName] = useState('');
  const [description, setDescription] = useState('');
  const [deadline, setDeadline] = useState('');
  const [tagId, setTagId] = useState('');
  const [profileId, setProfileId] = useState('');
  
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    if (projectId) {
      const project = projects.find(p => p.id === projectId);
      if (project) {
        setName(project.name);
        setDescription(project.description);
        setDeadline(project.deadline ? project.deadline.substring(0, 10) : '');
        setTagId(project.tagId || '');
        setProfileId(project.profileId || '');
      }
    }
  }, [projectId, projects]);

  const handleSave = () => {
    if (!name.trim()) {
      setError("Nome do projeto é obrigatório");
      return;
    }

    const data: Omit<Project, 'id'> = {
      name: name.trim(),
      description: description.trim(),
      deadline: deadline ? new Date(deadline).toISOString() : undefined,
      tagId: tagId || undefined,
      profileId: profileId || undefined,
    };

    if (projectId) {
      updateProject(projectId, data);
    } else {
      addProject(data);
    }
    onClose();
  };

  return (
    <div className="fixed inset-0 bg-black/50 z-[100] flex justify-center items-end sm:items-center">
      <div className="bg-white w-full max-w-lg rounded-t-2xl sm:rounded-2xl shadow-xl flex flex-col max-h-[90vh]">
        <div className="flex justify-between items-center p-6 border-b border-gray-100 shrink-0">
          <h2 className="text-xl font-bold text-gray-800">{projectId ? 'Editar Projeto' : 'Novo Projeto'}</h2>
          <button onClick={onClose} className="p-2 hover:bg-gray-100 rounded-full text-gray-500">
            <X size={20} />
          </button>
        </div>

        <div className="overflow-y-auto p-6 flex-1 space-y-4">
          {error && (
            <div className="flex items-center gap-2 p-3 bg-red-50 text-red-600 rounded-lg text-sm border border-red-100 font-medium">
              <AlertCircle size={16} /> {error}
            </div>
          )}

          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">Nome do projeto *</label>
            <input 
              type="text" 
              value={name}
              onChange={(e) => setName(e.target.value)}
              className="w-full border border-gray-300 rounded-lg px-3 py-2 outline-none focus:ring-2 focus:ring-blue-500 text-lg"
              placeholder="Ex: Reforma da casa"
            />
          </div>

          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">Descrição</label>
            <textarea 
              value={description}
              onChange={(e) => setDescription(e.target.value)}
              className="w-full border border-gray-300 rounded-lg px-3 py-2 outline-none focus:ring-2 focus:ring-blue-500 min-h-[80px] resize-none text-sm"
              placeholder="Detalhes opcionais sobre o projeto..."
            />
          </div>

          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1 flex items-center gap-1">
              <Calendar size={14} /> Prazo
            </label>
            <input 
              type="date" 
              value={deadline}
              onChange={(e) => setDeadline(e.target.value)}
              className="w-full border border-gray-300 rounded-lg px-3 py-2 outline-none focus:ring-2 focus:ring-blue-500 text-sm"
            />
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1 flex items-center gap-1">
                <TagIcon size={14} /> Tag
              </label>
              <select 
                value={tagId}
                onChange={(e) => setTagId(e.target.value)}
                className="w-full border border-gray-300 rounded-lg px-3 py-2 outline-none focus:ring-2 focus:ring-blue-500 text-sm"
              >
                <option value="">Sem tag</option>
                {tags.map(t => <option key={t.id} value={t.id}>{t.name}</option>)}
              </select>
            </div>
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1 flex items-center gap-1">
                <Settings2 size={14} /> Perfil Padrão
              </label>
              <select 
                value={profileId}
                onChange={(e) => setProfileId(e.target.value)}
                className="w-full border border-gray-300 rounded-lg px-3 py-2 outline-none focus:ring-2 focus:ring-blue-500 text-sm"
              >
                <option value="">Sem perfil</option>
                {profiles.map(p => <option key={p.id} value={p.id}>{p.name}</option>)}
              </select>
            </div>
          </div>
        </div>

        <div className="p-4 border-t border-gray-100 flex justify-between gap-3 shrink-0 bg-gray-50 rounded-b-2xl">
          {projectId ? (
            <button 
              onClick={() => {
                if (confirm('Tem certeza que deseja excluir este projeto? (Suas tarefas não serão excluídas)')) {
                  deleteProject(projectId);
                  onClose();
                }
              }}
              className="px-4 py-2 text-red-600 hover:bg-red-50 rounded-lg font-medium transition-colors"
            >
              Excluir
            </button>
          ) : <div></div>}
          
          <div className="flex gap-3">
            <button 
              onClick={onClose}
              className="px-4 py-2 text-gray-600 hover:bg-gray-200 rounded-lg font-medium transition-colors"
            >
              Cancelar
            </button>
            <button 
              onClick={handleSave}
              className="px-4 py-2 bg-blue-600 hover:bg-blue-700 text-white rounded-lg font-medium transition-colors"
            >
              Salvar
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}