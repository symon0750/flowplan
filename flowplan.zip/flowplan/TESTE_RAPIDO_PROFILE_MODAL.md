# 🚀 Guia Rápido - Como Testar a Auditoria

**Status**: ✅ Build completo e pronto para testes  
**Arquivo de Deploy**: dist/index.html (349.47 kB)

---

## 1️⃣ Iniciar o Servidor de Desenvolvimento

```bash
cd c:\projetos6\flowplan
npm run dev
```

Aguarde a mensagem:
```
VITE v7.2.4 ready in XXX ms

➜  Local:   http://localhost:5173/
```

Abra no browser: **http://localhost:5173**

---

## 2️⃣ Navegar até a Seção de Perfis

```
1. Abrir aplicação no browser
2. Click na aba "Ajustes" (última aba)
3. Look for section "Perfis de horário"
4. Click no título para expandir (se fechado)
```

---

## 3️⃣ Testar: Criar Novo Perfil

```
1. Click "+ Criar novo perfil"
2. Preencher:
   - Nome: "Teste Novo"
   - Intervalo: 10
   - Horário Padrão: 08:00 - 17:00
3. Click "Adicionar pausa" → Almoço, 12:00 - 13:00
4. Click "Salvar"
5. Perfil deve aparecer na lista

VERIFICAÇÃO: Botão "Excluir" NÃO deve aparecer na modal ✅
```

---

## 4️⃣ Testar: Editar Perfil

```
1. Click ícone "Editar" (✏️) em um perfil
2. ProfileModal abre com "Editar Perfil de Horário" no título
3. Modificar um campo (ex: Intervalo para 15)
4. Click "Salvar"
5. Modal fecha, lista atualiza

VERIFICAÇÃO: Botão "Excluir" DEVE aparecer na footer! ✅
```

---

## 5️⃣ Testar: Deletar com Confirmação ⭐

```
1. Click "Editar" em um perfil
2. ProfileModal abre
3. ENCONTRE O BOTÃO "Excluir" (footer esquerda, vermelho)
4. Click "Excluir"
5. Modal de confirmação aparece

VERIFICAÇÕES:
   ✅ Ícone de alerta (⚠️) aparece
   ✅ Titulo: "Excluir Perfil"
   ✅ Aviso: "Esta ação é permanente"
   ✅ Mensagem mostra o nome do perfil em negrito
   ✅ Botões: "Cancelar" (cinza) e "Excluir Perfil" (vermelho)

6. Click "Excluir Perfil"
7. Ambas modals fecham
8. Volta para Ajustes
9. Perfil desapareceu da lista

VERIFICAÇÃO FINAL: Perfil foi deletado! ✅
```

---

## 6️⃣ Testar: Cancelar Delete

```
1. Click "Editar" em um perfil
2. Click "Excluir"
3. Modal de confirmação aparece
4. Click "Cancelar"
5. Modal de confirmação fecha
6. ProfileModal ainda aberta
7. Dados intactos

VERIFICAÇÃO: Perfil NÃO foi deletado ✅
```

---

## 7️⃣ Testar: Validações

### Validação 1: Nome obrigatório
```
1. Novo perfil
2. Deixar nome vazio
3. Click "Salvar"
4. Erro: "Preencha o nome do perfil"
✅ PASSA
```

### Validação 2: Hora invertida
```
1. Novo perfil
2. Horário: 18:00 - 08:00 (invertido)
3. Click "Salvar"
4. Erro: "A hora inicial deve ser antes da hora final"
✅ PASSA
```

### Validação 3: Pausas encostam (permitido)
```
1. Novo perfil
2. Nome: "Test"
3. Horário: 08:00 - 18:00
4. Pausa 1: 10:00 - 12:00
5. Pausa 2: 12:00 - 13:00 (encosta)
6. Click "Salvar"
7. ✅ Deve SALVAR (encostamento é permitido)
```

### Validação 4: Pausas sobrepõem (bloqueado)
```
1. Novo perfil
2. Nome: "Test"
3. Horário: 08:00 - 18:00
4. Pausa 1: 10:00 - 12:00
5. Pausa 2: 11:00 - 13:00 (sobrepõe)
6. Click "Salvar"
7. Erro: "Esta pausa se sobrepõe a outra pausa existente"
✅ PASSA
```

---

## 8️⃣ Testar: Persistência em IndexedDB

```
1. Criar um perfil: "IndexedDB Test"
2. Preencher todos os dados
3. Click "Salvar"
4. Abrir DevTools: F12
5. Application tab
6. IndexedDB → flowplan-db → profiles
7. Procurar pela chave do perfil
8. Double-click ou expand para ver os dados

VERIFICAÇÕES:
   ✅ Perfil visível em IndexedDB
   ✅ Todos os campos presentes (name, interval, standardStart, etc)
   ✅ standardPauses array visível
   ✅ days object visível

9. Fechar DevTools (F12 novamente)
10. Press F5 (recarregar página)
11. Abrir Ajustes
12. Perfil ainda lá com todos os dados

✅ Esperado: Dados persistem
```

---

## 9️⃣ Testar: Fluxo Completo

```
CENÁRIO: Criar, Editar, Deletar

Passo 1: CRIAR
├─ Click "+ Criar novo perfil"
├─ Nome: "Meu Perfil"
├─ Intervalo: 5
├─ Horário: 08:00 - 18:00
├─ Pausa: "Almoço" 12:00 - 13:00
├─ Segunda: Customizado, 09:00 - 17:30
└─ Click "Salvar"
   → Perfil aparece na lista ✅

Passo 2: EDITAR
├─ Click "Editar"
├─ Mudar nome para "Meu Perfil - Produção"
├─ Adicionar pausa: "Café" 15:00 - 15:15
└─ Click "Salvar"
   → Lista atualiza ✅

Passo 3: VERIFICAR PERSISTÊNCIA
├─ Recarregar: F5
├─ Abrir Ajustes
└─ Perfil "Meu Perfil - Produção" ainda lá com ambas pausas ✅

Passo 4: DELETAR
├─ Click "Editar"
├─ Click "Excluir" (footer)
├─ Modal de confirmação aparece
├─ Click "Excluir Perfil"
└─ Perfil desaparece da lista ✅

Passo 5: CONFIRMAR DELETE
├─ Recarregar: F5
└─ Perfil não existe mais ✅

RESULTADO FINAL: ✅ TUDO FUNCIONA!
```

---

## 🔍 Verificações no Console

Se tiver erros, abrir Console (F12 → Console tab):

### Esperado:
```
✅ Sem mensagens de erro vermelho
✅ Sem mensagens de warning amarelo
✅ Cache limpo e assets carregam
```

### Se tiver erro:
```
❌ Clique em erro para ver stack trace
❌ Anote o erro exato
❌ Verifique se IndexedDB está funcionando
```

---

## 🧪 Checklist de Testes

- [ ] **Teste 1**: Criar novo perfil (descrito acima) ✅
- [ ] **Teste 2**: Editar perfil ✅
- [ ] **Teste 3**: Deletar com confirmação ✅
- [ ] **Teste 4**: Cancelar delete ✅
- [ ] **Teste 5**: Validação - nome obrigatório ✅
- [ ] **Teste 6**: Validação - hora invertida ✅
- [ ] **Teste 7**: Validação - pausas encostam ✅
- [ ] **Teste 8**: Validação - pausas sobrepõem ✅
- [ ] **Teste 9**: Persistência em IndexedDB ✅
- [ ] **Teste 10**: Fluxo completo ✅
- [ ] **Teste 11**: Recarregamento mantém dados ✅
- [ ] **Teste 12**: Sem erros no console ✅

---

## 🐛 Se Algo Não Funcionar

### Problema: Modal de delete não aparece
```
Solução:
1. Verificar se está em modo edição (tem um perfil)
2. Abrir DevTools (F12)
3. Procurar por erro no console
4. Recarregar página (F5)
```

### Problema: Botão "Excluir" não aparece
```
Solução:
1. Verificar que está editando (profileId deve ter valor)
2. Recarregar página
3. Verificar cache: Ctrl+Shift+Delete
4. Fazer hard refresh: Ctrl+Shift+R
```

### Problema: Perfil não deleta
```
Solução:
1. Verificar DevTools → IndexedDB
2. Confirmar que banco existe (flowplan-db)
3. Confirmar que object store 'profiles' existe
4. Recarregar aplicação
```

### Problema: Dados não persistem após reload
```
Solução:
1. DevTools → Application → Storage → Clear site data
2. Fechar DevTools
3. Recarregar página (F5)
4. Criar novo perfil
5. Recarregar de novo
6. Se ainda não funcionar, listar em console:
   localStorage.getItem('flowplan-db')
```

---

## 📞 Suporte

Se encontrar problemas:

1. **Verificar build**: `npm run build`
2. **Limpar cache**: `rm -rf .next node_modules dist`
3. **Reinstalar**: `npm install`
4. **Recompilar**: `npm run build`
5. **Servidor dev**: `npm run dev`

---

## ✅ Conclusão do Teste

Se todos os 12 checkboxes acima estão marcados ✅, então:

🎉 **A AUDITORIA PASSOU COM SUCESSO!**

Todos os 15 requisitos estão implementados e funcionando corretamente.

---

**Tempo estimado de testes**: 30-45 minutos  
**Data de início**: [Preencher]  
**Data de conclusão**: [Preencher]  
**Testador**: [Preencher]  
**Status**: ⏳ PRONTO PARA TESTAR
