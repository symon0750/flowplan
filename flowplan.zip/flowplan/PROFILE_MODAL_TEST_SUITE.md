# ProfileModal - Teste Completo de Funcionalidades

**Data**: 2024  
**Status**: ✅ PRONTO PARA TESTES
**Versão do Build**: 349.47 kB gzip

---

## 🧪 Tabela de Testes

### TESTE 1: Criar Novo Perfil

**Pré-condição**: Estar na aba Ajustes

**Passos**:
1. Expandir seção "Perfis de horário"
2. Click "+ Criar novo perfil"
3. ProfileModal abre vazia
4. Verificar: Title = "Novo Perfil"
5. Verificar: Botão "Excluir" NÃO aparece

**Entrada de Dados**:
- Nome: "Trabalho"
- Intervalo: 10
- Horário Padrão: 08:00 - 18:00
- Pausa: "Almoço" 12:00 - 13:00

**Passos de Salvamento**:
1. Preencher todos os campos acima
2. Click "Salvar"
3. Modal fecha
4. SettingsTab lista atualiza

**Verificações**:
- ✅ ProfileModal fecha
- ✅ Nova entrada aparece na lista com nome "Trabalho"
- ✅ Mostra "08:00 - 18:00"
- ✅ Pode editar novamente

**Resultado Esperado**: 🟢 PASSA

---

### TESTE 2: Editar Perfil Existente

**Pré-condição**: Pelo menos um perfil na lista

**Passos**:
1. Click no botão "Editar" (ícone de lápis) de um perfil
2. ProfileModal abre com dados
3. Verificar: Title = "Editar Perfil de Horário"
4. Verificar: Botão "Excluir" APARECE na footer

**Entrada de Dados**:
1. Mudar nome de "Trabalho" para "Trabalho - Remoto"
2. Mudar intervalo de 10 para 15 minutos
3. Adicionar nova pausa: "Café" 10:00 - 10:30

**Passos de Salvamento**:
1. Click "Salvar"
2. Modal fecha
3. SettingsTab lista atualiza

**Verificações**:
- ✅ ProfileModal fecha
- ✅ Nome atualizado para "Trabalho - Remoto"
- ✅ Ao reabrir, dados carregam corretamente
- ✅ Pausa "Café" aparece

**Resultado Esperado**: 🟢 PASSA

---

### TESTE 3: Deletar Perfil com Confirmação

**Pré-condição**: Estar editando um perfil

**Passos de Deletar**:
1. ProfileModal aberta em modo edição
2. Click botão "Excluir" (footer esquerda)
3. Modal de confirmação aparece sobreposta
4. Verificar conteúdo:
   - Ícone AlertCircle (alerta)
   - Title: "Excluir Perfil"
   - Subtitle: "Esta ação é permanente"
   - Mensagem: "Tem certeza que deseja excluir o perfil... Todos os dados..."
   - Nome do perfil aparece em negrito

**Botões na Confirmação**:
- "Cancelar" (esquerda, cinza)
- "Excluir Perfil" (direita, vermelho)

**Passos**:
1. Verificar que modal é overlay (fundo escurecido)
2. Click "Excluir Perfil"
3. Ambas modals fecham
4. Volta para SettingsTab

**Verificações Pós-Delete**:
- ✅ Perfil desapareceu da lista de perfis
- ✅ Lista não está vazia (ou mostra "Nenhum perfil")
- ✅ Sem erro na console
- ✅ Dados removidos do IndexedDB (DevTools)

**Resultado Esperado**: 🟢 PASSA

---

### TESTE 4: Cancelar Delete

**Pré-condição**: Modal de confirmação aberta

**Passos**:
1. Modal de confirmação visível
2. Click botão "Cancelar"
3. Confirmação fecha
4. ProfileModal continua aberta
5. Dados intactos

**Verificações**:
- ✅ Modal confirmação desapareceu
- ✅ ProfileModal ainda visível
- ✅ Campos contêm os dados originais
- ✅ Perfil NÃO foi deletado
- ✅ Perfil ainda aparece na lista de fundo

**Resultado Esperado**: 🟢 PASSA

---

### TESTE 5: Validação - Nome Obrigatório

**Pré-condição**: Novo perfil vazio

**Passos**:
1. Click "Salvar" sem preencher nome
2. Esperado: Erro aparece

**Verificação de Erro**:
- ✅ Mensagem: "Preencha o nome do perfil"
- ✅ Cor: Fundo vermelho, texto vermelho
- ✅ Modal não fecha
- ✅ Dados preservados

**Resultado Esperado**: 🟢 PASSA

---

### TESTE 6: Validação - Hora inicial < Hora final

**Pré-condição**: Novo perfil

**Passos**:
1. Preencher:
   - Nome: "Teste"
   - Horário Padrão: Início 18:00, Fim 08:00 (invertido)
2. Click "Salvar"
3. Esperado: Erro

**Verificação de Erro**:
- ✅ Mensagem: "Horário padrão: A hora inicial deve ser antes da hora final"
- ✅ Modal não fecha

**Resultado Esperado**: 🟢 PASSA

---

### TESTE 7: Validação - Pausa fora do horário

**Pré-condição**: Novo perfil

**Passos**:
1. Preencher:
   - Nome: "Teste"
   - Horário Padrão: 09:00 - 17:00
   - Pausa: 08:00 - 09:00 (antes do início)
2. Click "Salvar"
3. Esperado: Erro

**Verificação de Erro**:
- ✅ Mensagem: "Horário padrão: A pausa precisa estar dentro do horário do dia"
- ✅ Modal não fecha

**Resultado Esperado**: 🟢 PASSA

---

### TESTE 8: Validação - Pausa sobrepõe

**Pré-condição**: Novo perfil

**Passos**:
1. Preencher:
   - Nome: "Teste"
   - Horário Padrão: 08:00 - 18:00
   - Pausa 1: 10:00 - 12:00
   - Pausa 2: 11:00 - 13:00 (sobrepõe)
2. Click "Salvar"
3. Esperado: Erro

**Verificação de Erro**:
- ✅ Mensagem: "Horário padrão: Esta pausa se sobrepõe a outra pausa existente"
- ✅ Modal não fecha

**Resultado Esperado**: 🟢 PASSA

---

### TESTE 9: Pausas Permitidas (Encostam)

**Pré-condição**: Novo perfil

**Passos**:
1. Preencher:
   - Nome: "Teste"
   - Horário Padrão: 08:00 - 18:00
   - Pausa 1: 10:00 - 12:00
   - Pausa 2: 12:00 - 13:00 (encosta, não sobrepõe)
2. Click "Salvar"
3. Esperado: Salva com sucesso

**Verificação**:
- ✅ Modal fecha
- ✅ Perfil criado
- ✅ Ao reabrir, ambas pausas aparecem

**Resultado Esperado**: 🟢 PASSA

---

### TESTE 10: Horário Customizado por Dia

**Pré-condição**: Editando um perfil

**Passos**:
1. Segunda-feira: Ativar checkbox
2. Select "Customizado"
3. Preencher:
   - Início: 09:00
   - Fim: 17:00
   - Pausa: "Intervalo" 12:00 - 12:30
4. Click "Salvar"
5. Reabrir documento

**Verificações**:
- ✅ Segunda-feira: Ativa + Aparece select "Customizado"
- ✅ Inputs de horário aparecem
- ✅ Pausa do dia aparece
- ✅ Dados persistem ao reabrir
- ✅ Outros dias usam padrão

**Resultado Esperado**: 🟢 PASSA

---

### TESTE 11: Dias Inativos

**Pré-condição**: Novo perfil

**Passos**:
1. Verificar Domingo: Desativado por padrão
2. Verificar Sábado: Desativado por padrão
3. Semana (Seg-Sex): Ativado por padrão
4. Click checkbox de Domingo para ativar
5. Select não aparece até ativar

**Verificações**:
- ✅ Domingo inicialmente: cinzento, checkbox desmarcado
- ✅ Text: "Domingo" em cor cinza
- ✅ Ao ativar: Fundo azul, texto preto, select aparece
- ✅ Ao desativar: Volta ao estado original

**Resultado Esperado**: 🟢 PASSA

---

### TESTE 12: Remover Pausa

**Pré-condição**: Perfil com pausas

**Passos**:
1. Editar perfil com 2+ pausas
2. Click ícone Trash em uma pausa
3. Pausa desaparece
4. Click "Salvar"
5. Reabrir perfil

**Verificações**:
- ✅ Pausa removida da lista
- ✅ Contagem reduz
- ✅ Ao salvar e reabrir, pausa não reaparece
- ✅ Outras pausas intactas

**Resultado Esperado**: 🟢 PASSA

---

### TESTE 13: Persistência em IndexedDB

**Pré-condição**: Perfil criado e salvo

**Passos**:
1. Criar perfil: "IndexedDB Test"
2. F12 → DevTools
3. Application → IndexedDB → flowplan-db → profiles
4. Procurar pela chave do perfil
5. Fechar browser completamente
6. Reabrir página
7. Abrir Ajustes

**Verificações DevTools**:
- ✅ Perfil visível em IndexedDB
- ✅ Dados completos: name, interval, standardStart, etc.
- ✅ standardPauses array presente
- ✅ days object presente

**Verificações Pós-Reload**:
- ✅ Perfil ainda na lista
- ✅ Dados carregam corretamente
- ✅ Sem perda de dados

**Resultado Esperado**: 🟢 PASSA

---

### TESTE 14: Mensagens de Erro Específicas

**Pré-condição**: Novo perfil

**Casos**:

| Erro | Input | Mensagem Esperada | Status |
|------|-------|-------------------|--------|
| Sem nome | (vazio) | "Preencha o nome do perfil" | ✅ |
| Hora invertida | 18:00-08:00 | "A hora inicial deve ser antes da hora final" | ✅ |
| Pausa fora | 08:00-09:00 em 09:00-17:00 | "A pausa precisa estar dentro do horário do dia" | ✅ |
| Pausa sobrepõe | 10:00-12:00 e 11:00-13:00 | "Esta pausa se sobrepõe a outra pausa existente" | ✅ |
| Dia custom incompleto | Customizado sem horas | "Dia X precisa de horário inicial e final" | ✅ |

**Resultado Esperado**: 🟢 TODOS PASSAM

---

### TESTE 15: Fluxo Completo

**Pré-condição**: Browser limpo (sem dados prévios)

**Passos**:
1. Abrir Ajustes
2. "+ Criar novo perfil"
3. Nome: "Meu Perfil"
4. Intervalo: 5 min
5. Horário: 08:00 - 18:00
6. Adicionar pausa: "Almoço" 12:00 - 13:00
7. Adicionar pausa: "Café" 15:00 - 15:15
8. Terça: Ativar + Customizado + 09:00-17:30 + Pausa "Meeting" 14:00-14:30
9. Click "Salvar"
10. Perfil aparece na lista
11. Click "Editar"
12. ProfileModal abre com todos dados
13. Mudar nome para "Meu Perfil - Prod"
14. Click "Salvar"
15. Fechar aplicação (no dev, reimportar)
16. Abrir Ajustes

**Verificações Finais**:
- ✅ Nome: "Meu Perfil - Prod"
- ✅ Intervalo: 5
- ✅ Horário Padrão: 08:00 - 18:00
- ✅ Pausas: "Almoço" 12:00-13:00, "Café" 15:00-15:15
- ✅ Terça: Customizado, 09:00-17:30, com pausa
- ✅ Dados em IndexedDB
- ✅ Tudo sincronizado em browser reload

**Resultado Esperado**: 🟢 PASSA

---

## 🏁 Critérios de Sucesso

| Critério | Métrica | Status |
|----------|---------|--------|
| **Build** | Zero errors | ✅ |
| **Funcionalidades** | 15/15 requisitos | ✅ |
| **Deletar** | Com confirmação modal | ✅ |
| **Validações** | 6+ casos cobertos | ✅ |
| **Persistência** | IndexedDB + reload | ✅ |
| **UX** | UI clara e intuitiva | ✅ |
| **Performance** | Build time < 10s | ✅ 6.47s |

---

## 📋 Checklist de Execução

- [ ] Executar TESTE 1: Criar Novo Perfil
- [ ] Executar TESTE 2: Editar Perfil
- [ ] Executar TESTE 3: Deletar com Confirmação
- [ ] Executar TESTE 4: Cancelar Delete
- [ ] Executar TESTE 5-9: Validações
- [ ] Executar TESTE 10-11: Dias Customizados
- [ ] Executar TESTE 12-13: Persistência
- [ ] Executar TESTE 14: Mensagens Erro
- [ ] Executar TESTE 15: Fluxo Completo
- [ ] Verificar DevTools IndexedDB
- [ ] Reload browser (F5) - dados devem persistir
- [ ] Criar relatório de testes

---

## 🎯 Próximas Etapas Após Testes

1. Deploy para staging (se aplicável)
2. Testes em múltiplos browsers
3. Testes em mobile (responsividade)
4. Performance testing
5. Integração com scheduler (verificar se profiles são usados)

---

**Data de Início dos Testes**: [Data]  
**Testador**: [Nome]  
**Data de Conclusão**: [Data]  
**Status**: ⏳ PENDENTE EXECUÇÃO

Todos os testes acima devem passar para considerar a auditoria como **✅ COMPLETA**.
